//
// QSINIT EFI loader
// load and prepare 32-bit binary part
//
#include "qsloader.h"
#include "qsbinfmt.h"
#include "efilib.h"
#include <string.h>
#include "qsefi32.h"
#include "qsinit.h"
#include "dskinfo.h"
#include "seldesc.h"

#define MIN_STACK32_SIZE     98304   // min 96k of stack

extern EFI_PHYSICAL_ADDRESS    QSMem;
extern UINTN                 QSPages;
extern EFI_PHYSICAL_ADDRESS  GDTCopy;  // own GDT
extern UINT32                GDTSize,  // size of GDT in bytes
                           GDTLowest;  // lowest usable selector
extern u32t             unpackMemReq;
extern UINT32               SafeMode;

UINT64                     Ret64Addr;
UINT64                    Xcpt64Addr;
UINT64                    Init32Addr;
UINT64                       Stack32;
u8t                   *mfsd_openname;  // file open name in 32-bit DGROUP
u8t                       *DiskBufPM;  // disk i/o buffer
exp32_table                *Header32 = 0;

u32t decompress(u32t DataLen, void* Src, void* Dst, u8t* Buffer);
void Callback32(void);
void Ret32Point(void);
void XcptRet32(void);

void make_selectors(u32t cssel) {
   struct desctab_s *sd = (struct desctab_s *)(GDTCopy + cssel);
   sd->d_limit   = 0xFFFF;
   sd->d_access  = D_CODE0;
   sd->d_attr    = D_DBIG|D_GRAN4K|D_AVAIL|0x0F;
   sd++;
   sd->d_limit   = 0xFFFF;
   sd->d_access  = D_DATA0;
   sd->d_attr    = D_DBIG|D_GRAN4K|D_AVAIL|0x0F;
}


int Load32(void) {
   MKBIN_HEADER *hdr = (MKBIN_HEADER*)&qs32_data;
   u8t       *unpBuf = AllocatePool(unpackMemReq);
   u8t         *base = (u8t*)QSMem;
   exp32_table *etab = 0;
   u32t        szbss, szfx, ii;
   rels_type   *fx_s;
   relo_type   *fx_o;

   if (hdr->fxRelCnt) ErrorExit(L"Relative fixup present in 32-bit code!\n");
   /* not possible, but still check, at least once.
      many internal pointers will be sent directly to 32-bit code */
   if ((u64t)hdr>=_4GBLL) ErrorExit(L"Fixme! We`re loaded above 4GB!\n");

   if (hdr->pmPacked!=hdr->pmTotal) {
      //Print(L"Call decompress (%d, %X, %X, %X)...\n", hdr->pmPacked, hdr+1, base, unpBuf);
      if (decompress(hdr->pmPacked, hdr+1, base, unpBuf) != hdr->pmTotal)
         ErrorExit(L"Decompress error (a part of module is damaged)!\n");
   } else
      memcpy(base, hdr+1, hdr->pmTotal);

   //Print(L"Fixuping\n");

   // fixups present? move it above BSS space
   szfx  = hdr->pmTotal-hdr->pmStored;
   if (szfx) memmove(base+hdr->pmSize, base+hdr->pmTotal-szfx, szfx);
   // zero BSS
   szbss = hdr->pmSize-hdr->pmStored;
   if (szbss) memset(base+hdr->pmStored, 0, szbss);
   // apply selector fixups
   fx_s = (rels_type*)(base+hdr->pmSize);
   for (ii=0; ii<hdr->fxSelCnt; ii++) {
      switch (fx_s->rs_seltype) {
         case FXSEL32CS: *(u16t*)(base+fx_s->rs_offset) = GDTLowest;   break;
         case FXSEL32DS: *(u16t*)(base+fx_s->rs_offset) = GDTLowest+8; break;
      }
      fx_s++;
   }
   // apply offset fixups
   fx_o = (relo_type*)(fx_s);
   for (ii=0; ii<hdr->fxOfsCnt; ii++) {
      if (fx_o->ro_tgt16) ErrorExit(L"Incorrect flag in fixup!\n");
      *(u32t*)(base+fx_o->ro_offset) = (u32t)QSMem + fx_o->ro_target;
      fx_o++;
   }
   FreePool(unpBuf);

   etab = (exp32_table*)(QSMem + hdr->pmEntry);
   // check structure size match between 32-bit & 64-bit parts
   if (etab->size!=sizeof(exp32_table)) ErrorExit(L"Wrong build!\n");
   else {
      struct 
      qs_diskinfo  *qdd = (struct qs_diskinfo *)(u64t)etab->qd_array;
      u32t     stackpos = (u32t)QSMem+hdr->pmSize,
               stackend = Round64k(stackpos + MIN_STACK32_SIZE + LOGBUF_SIZE + DISKBUF_SIZE);
      // fill variables of 32-bit part
      etab->phmembase   = stackend;
      etab->availmem    = ((u32t)QSPages<<EFI_PAGE_SHIFT) - (etab->phmembase-(u32t)QSMem) & 0xFFFF0000;
      etab->memblocks   = etab->availmem>>16;
      etab->highbase    = (u32t)QSMem;
      etab->highlen     = (u32t)QSPages<<EFI_PAGE_SHIFT;
      // disk buffer aligned to 32k in phys. mem, so ignore IOAlign in EFI i/o
      etab->DiskBufPM   = stackend-=DISKBUF_SIZE;
      etab->logrmbuf    = stackend-=LOGBUF_SIZE;
      etab->gdt_pos     = (u32t)GDTCopy;
      etab->gdt_size    = (u16t)GDTSize;
      etab->gdt_lowest  = (u16t)GDTLowest;
      etab->pbin_header = (u32t)(u64t)hdr;
      etab->IODelay     = tm_calibrate();
      etab->safeMode    = SafeMode ? 1 : 0;
      etab->flat32cs    = GDTLowest;
      etab->sel64       = GetCodeSelector();
      // we checked module location at the start of this function
      etab->ofs64       = (u32t)(u64t)&Callback32;
      etab->ret32       = (u32t)(u64t)&Ret32Point;
      etab->xcpt32      = (u32t)(u64t)&XcptRet32;
      etab->bootdisk    = FFFF;
      // ptr to file name to open
      mfsd_openname     = (u8t*)(u64t)etab->mfsd_openname;
      DiskBufPM         = (u8t*)(u64t)etab->DiskBufPM;
      // setup disk i/o
      dsk_init(etab,qdd);
      // make flat cs/ds
      make_selectors(etab->flat32cs);
      // 16:32 address for return to 32-bit code
      Ret64Addr  = (u64t)etab->flat32cs<<32 | etab->ret64;
      // 16:32 address for 32-bit start point
      Init32Addr = (u64t)etab->flat32cs<<32 | etab->entry;
      // 16:32 address for 32-bit common exception handling code
      Xcpt64Addr = (u64t)etab->flat32cs<<32 | etab->xcpt64;
      // ss:esp for 32-bit stack
      Stack32    = (u64t)(etab->flat32cs+8)<<32 | stackend;
      // header ready
      Header32 = etab;
      //DumpHex(0,0,sizeof(exp32_table),etab);
   }

   return 0;
}
