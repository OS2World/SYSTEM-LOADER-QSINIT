//
// QSINIT EFI loader
// keyboard functions
//
#include "qsloader.h"
#include "efilib.h"
#include "inputex.h"

static u16t    lastkey = 0;    // last key pressed
static u32t  laststate = 0;    // last keyboard state
EFI_GUID   InputExGuid = EFI_SIMPLE_TEXT_INPUT_EX_PROTOCOL_GUID;

// UEFI 2.1 protocol
EFI_SIMPLE_TEXT_INPUT_EX_PROTOCOL  *ConInEx = 0;

void key_init(void) {
   // trying to acquire a better life
   if (BS->HandleProtocol(ST->ConsoleInHandle, &InputExGuid, (VOID **)&ConInEx)) ConInEx = 0;

   if (!ConInEx) log_it(0, L"No extended input!\n");
}

u32t key_status(void) {
   return laststate;
}

/* this function handle not all scan codes, actually - but most of required for QSINIT
   and Turbo Vision library */
static u16t key_ask(int wait, u32t seconds) {
   u16t     rc = 0;
   UINT16 scan = 0;
   CHAR16  chr = 0;

   if (ConInEx) {
      EFI_KEY_DATA  Kbs;
      UINT32         st;

      if (wait && !seconds) {
         while (ConInEx->ReadKeyStrokeEx(ConInEx, &Kbs)) /*CpuHlt()*/;
      } else {
         if (wait) WaitForSingleEvent(ConInEx->WaitForKeyEx, (u64t)seconds*10000000);
         if (ConInEx->ReadKeyStrokeEx(ConInEx, &Kbs)) return 0;
      }

      laststate = 0;
      st = Kbs.KeyState.KeyShiftState;
      if (st & EFI_SHIFT_STATE_VALID) {
         if (st & EFI_RIGHT_SHIFT_PRESSED)   laststate|=KEY_SHIFTRIGHT|KEY_SHIFT;
         if (st & EFI_LEFT_SHIFT_PRESSED)    laststate|=KEY_SHIFTLEFT|KEY_SHIFT;
         if (st & EFI_RIGHT_CONTROL_PRESSED) laststate|=KEY_CTRLRIGHT|KEY_CTRL;
         if (st & EFI_LEFT_CONTROL_PRESSED)  laststate|=KEY_CTRLLEFT|KEY_CTRL;
         if (st & EFI_RIGHT_ALT_PRESSED)     laststate|=KEY_ALTRIGHT|KEY_ALT;
         if (st & EFI_LEFT_ALT_PRESSED)      laststate|=KEY_ALTLEFT|KEY_ALT;
         if (st & EFI_SYS_REQ_PRESSED)       laststate|=KEY_SYSREQ;
      }
      st = Kbs.KeyState.KeyToggleState;
      if (st & EFI_TOGGLE_STATE_VALID) {
         if (st & EFI_SCROLL_LOCK_ACTIVE)    laststate|=KEY_SCROLLLOCK;
         if (st & EFI_NUM_LOCK_ACTIVE)       laststate|=KEY_NUMLOCK;
         if (st & EFI_CAPS_LOCK_ACTIVE)      laststate|=KEY_CAPSLOCK;
      }
      scan = Kbs.Key.ScanCode;
      chr  = Kbs.Key.UnicodeChar;
   } else {
      EFI_INPUT_KEY  Key;
      
      if (wait) WaitForSingleEvent (ST->ConIn->WaitForKey, (u64t)seconds*10000000);
      // read key
      if (ST->ConIn->ReadKeyStroke(ST->ConIn, &Key)) return 0;

      scan = Key.ScanCode;
      chr  = Key.UnicodeChar;
      //Print (L"Key Code:%X Scan:%X\n", (u32t)chr, (u32t)scan);
   }
   if (chr) {
      if (chr==CHAR_LINEFEED || chr==CHAR_CARRIAGE_RETURN) rc = 0x1C0D; else
      if (chr==CHAR_BACKSPACE) rc = 0x0E08; else
      if (chr==CHAR_TAB) rc = 0x0F09; else
      if (chr>=' ' && chr<0x7F) rc = chr;

      if (laststate) {
         if (rc==0x1C0D) { // Alt/Ctrl - Enter
            if (laststate&KEY_CTRL) rc = 0x1C0A; else
            if (laststate&KEY_ALT) rc = 0x1C00;
         } else
         if (rc==0x0E08) { // Alt/Ctrl - Backspace
            if (laststate&KEY_CTRL) rc = 0x0E7F; else
            if (laststate&KEY_ALT) rc = 0x0E00;
         } else
         if (rc==0x0F09) { // Alt/Ctrl/Shift - Tab
            if (laststate&KEY_CTRL) rc = 0x9400; else
            if (laststate&KEY_ALT) rc = 0xA500; else
            if (laststate&KEY_SHIFT) rc = 0x0F00;
         } else
         if (laststate&KEY_ALT) {
            switch (chr) {
               case '=': rc = 0x8300; break;
               case '/': rc = 0x3500; break;
               case '*': rc = 0x3700; break;
               case '+': rc = 0x4E00; break;
               case '-': rc = 0x8200; break;
               case '.': rc = 0x3400; break;
               case ',': rc = 0x3300; break;
               case ';': rc = 0x2700; break;
               case '[': rc = 0x1A00; break;
               case ']': rc = 0x1B00; break;
               case '`': rc = 0x2900; break;
               case '0': rc = 0x8100; break;
               case '\'': rc = 0x2800; break;
               case '\\': rc = 0x2B00; break;
               default:
                  if (chr>='1' && chr<='9') rc = (0x78 + (chr-'1')) << 8;
            }
         }
      }
   } else
   if (scan) {
      static UINT16 vscan[] = {
         SCAN_UP       ,SCAN_DOWN     ,SCAN_RIGHT    ,SCAN_LEFT     ,
         SCAN_HOME     ,SCAN_END      ,SCAN_INSERT   ,SCAN_DELETE   ,
         SCAN_PAGE_UP  ,SCAN_PAGE_DOWN,SCAN_F1       ,SCAN_F2       ,
         SCAN_F3       ,SCAN_F4       ,SCAN_F5       ,SCAN_F6       ,
         SCAN_F7       ,SCAN_F8       ,SCAN_F9       ,SCAN_F10      ,
         SCAN_F11      ,SCAN_F12      ,SCAN_ESC      ,0
      };
      static u16t value[] = {
         0x4800, 0x5000, 0x4D00, 0x4B00, 0x4700, 0x4F00, 0x5200, 0x5300,
         0x4900, 0x5100, 0x3B00, 0x3C00, 0x3D00, 0x3E00, 0x3F00, 0x4000,
         0x4100, 0x4200, 0x4300, 0x4400, 0x8500, 0x8600, 0x011B
      };
      int ii = 0;
      while (vscan[ii])
         if (vscan[ii]==scan) { rc = value[ii]; break; } else ii++;
   }
   /* 
      convert EFI key back to BIOS scan codes ;)
   */
   if (laststate) {
      if (rc>='A' && rc<='Z' || rc>='a' && rc<='z') {
         static u16t   value[] = {  0x1e00, 0x3000, 0x2e00, 0x2000, 0x1200,
    /* F */ 0x2100, 0x2200, 0x2300, 0x1700, 0x2400, 0x2500, 0x2600, 0x3200,
    /* N */ 0x3100, 0x1800, 0x1900, 0x1000, 0x1300, 0x1f00, 0x1400, 0x1600,
    /* V */ 0x2f00, 0x1100, 0x2d00, 0x1500, 0x2c00 };
         // convert 'A'..'Z' key to Alt-Key or Ctrl-Key code
         int idx = rc>='a' ? rc-'a' : rc-'A';
      
         if (laststate&KEY_ALT) rc = value[idx]; else
            if (laststate&KEY_CTRL) rc = idx + 1 | value[idx];  // Ctrl-Key = 1.. 0x1A
      } else
      if (scan>=SCAN_F1 && scan<=SCAN_F12) {
         int idx = scan - (scan>=SCAN_F11?SCAN_F11:SCAN_F1);

         if (laststate&KEY_ALT)   rc = ((scan<=SCAN_F10?0x68:0x8B) + idx) << 8; else
         if (laststate&KEY_CTRL)  rc = ((scan<=SCAN_F10?0x5E:0x89) + idx) << 8; else
         if (laststate&KEY_SHIFT) rc = ((scan<=SCAN_F10?0x54:0x87) + idx) << 8;
      } else {
         static u16t codes[] = { 0x9800, 0x8DE0, 0xA000, 0x91E0, 0x9D00, 0x74E0,
            0x9B00, 0x73E0, 0x9700, 0x77E0, 0x9F00, 0x75E0, 0xA200, 0x92E0,
            0xA300, 0x93E0, 0x9900, 0x84E0, 0xA100, 0x76E0, 0x0100, 0x011B };

         int   idx = laststate&KEY_ALT ? 0 : (laststate&KEY_CTRL ? 1 : -1);
         int  base = -1;

         if (idx>=0) {
            switch (scan) {
               case SCAN_UP       : base =  0; break;
               case SCAN_DOWN     : base =  2; break;
               case SCAN_RIGHT    : base =  4; break;
               case SCAN_LEFT     : base =  6; break;
               case SCAN_HOME     : base =  8; break;
               case SCAN_END      : base = 10; break;
               case SCAN_INSERT   : base = 12; break;
               case SCAN_DELETE   : base = 14; break;
               case SCAN_PAGE_UP  : base = 16; break;
               case SCAN_PAGE_DOWN: base = 18; break;
               case SCAN_ESC      : base = 20; break;
            }
            if (base>=0) rc = codes[base+idx];
         }
      }
   }
   //Print (L"%d, state %X\n", (u32t)rc, laststate);
   return rc;
}

u16t key_read(void) {
   u16t  rc = lastkey;
   // use key from key_pressed() or wait for a one
   if (lastkey) lastkey = 0; else
#if 1
      rc = key_ask(1,0);
#else
   do {
      rc = key_ask(1,0);
   } while (!rc);
#endif
   return rc;
}

u8t  key_pressed(void) {
   if (lastkey) return 1; else {
      u16t key = key_ask(0,0);

      if (key) lastkey = key;
      return key?1:0;
   }
}

u16t key_wait(u32t seconds, u32t *status) {
   u16t  rc = lastkey;
   // use key from key_pressed() or wait for a one
   if (lastkey) lastkey = 0; else rc = key_ask(seconds?1:0, seconds);
   if (rc && status) *status = laststate;
   return rc;
}
