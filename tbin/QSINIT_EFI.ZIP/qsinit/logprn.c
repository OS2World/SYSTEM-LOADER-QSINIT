//
// QSINIT EFI loader
// log & minor runtime
//
#include "qsloader.h"
#include "efilib.h"
#include "qsinit.h"
#include "efistdarg.h"

// use internal EFI Lib call to make life more friendly
VOID _PoolCatPrint (IN CHAR16 *fmt, IN va_list args, IN OUT POOL_PRINT *spc,
   IN INTN (*Output)(VOID *context, CHAR16 *str));

INTN _SPrint (IN VOID *Context, IN CHAR16 *Buffer);

int log_it(int level, CHAR16 *fmt, ...) {
   if (!Header32) return 0; else {
      va_list     args;
      POOL_PRINT   spc;
      char         *cp = (char*)(u64t)Header32->logrmbuf;
      u32t         pos = Header32->logrmpos;
      CHAR16    buffer[128], *cb = buffer;
      
      if (!cp || pos>=LOGBUF_SIZE-5) return 0;
      // print to buffer
      va_start (args, fmt);
      spc.str    = buffer;
      spc.maxlen = 128 - 1;
      spc.len    = 0;
      _PoolCatPrint (fmt, args, &spc, _SPrint);
      // level 0..3 and LOGIF_DELAY+LOGIF_REALMODE flags
      level = level&3|0x30;
      /* if there is no EOL at the end of last entry - appends this line to it,
         else starts a new entry */
      if (!pos || cp[pos-1]=='\n') {
         if (pos) pos++;
         cp[pos++] = (u8t)level;
      }
      while (pos<LOGBUF_SIZE-1)
         if (*cb=='\r') cb++; else
            if ((cp[pos] = (char)*cb++)==0) break; else pos++;
      // logrmpos must point to the term NULL in the last string!
      Header32->logrmpos = (u16t)pos;
   }
   return 1;
}

/// stricmp for A..Z chars
int RtStrICmp(const CHAR16 *s1, const CHAR16 *s2) {
   if (!s1&&!s2) return 0;
   if (!s1) return -1;
   if (!s2) return 1;
   while (1) {
      CHAR16 ch1 = *s1++,
             ch2 = *s2++;
      if (!ch1 && !ch2) return 0;
      if (!ch1) return -1;
      if (!ch2) return 1;
      if (ch1>='a' && ch1<='z') ch1-=0x20;
      if (ch2>='a' && ch2<='z') ch2-=0x20;
      if (ch1<ch2) return -1;
      if (ch1>ch2) return 1;
   }
}

void DumpHandleProtocols(const CHAR16 *info, EFI_HANDLE *eh) {
   EFI_STATUS    rc;
   EFI_GUID    **ga;
   UINTN      count;

   rc = BS->ProtocolsPerHandle(eh, &ga, &count);
   if (!EFI_ERROR(rc)) {
      EFI_DEVICE_PATH  *dp;
      UINTN           pidx;

      log_it(3, L"%s -> handle %x: %d protocols\n", info, eh, count);
      dp = DevicePathFromHandle(eh);
      if (dp) {
         CHAR16 *dpstr = DevicePathToStr(dp);
         log_it(3, L"device path: %s\n", dpstr);
         BS->FreePool(dpstr);
      }
      for (pidx=0; pidx<count; pidx++) log_it(3, L"%g\n", ga[pidx]);

      BS->FreePool(ga);
   } else {
      log_it(3, L"%s -> handle %x: %r\n", info, eh, rc);
   }
}
