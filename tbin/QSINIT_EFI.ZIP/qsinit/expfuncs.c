//
// QSINIT EFI loader
// export table for 32-bit code & some misc functions
//
#include "qsloader.h"
#include "efilib.h"

#define MEM_LIST_SIZE   512

// exports to 32-bit code
void *FuncTable[EFN_FUNCCOUNT] = { tm_calibrate, key_read, key_wait, 
   tm_counter, tm_getdate, tm_setdate, mfs_open, mfs_read, mfs_close,
   mfs_term, key_status, key_pressed, vio_charout, vio_strout,
   vio_clearscr, vio_setpos, vio_getpos, vio_setcolor, vio_getmode,
   vio_setmode, int15mem, vio_showcursor, exit_poweroff, vio_enummodes,
   grf_enummodes, vio_setmodeex, grf_setmode, grf_blit, grf_clear, dsk_io,
   hlp_setreg, XcptOn, hlp_memmove, TimerIrqsOn };

u32t         FuncCount = EFN_FUNCCOUNT;

typedef struct _AcpiMemInfo {
   u32t           BaseAddrLow;              ///< base address
   u32t          BaseAddrHigh;
   u32t             LengthLow;              ///< length in bytes
   u32t            LengthHigh;
   u32t           AcpiMemType;              ///< block type
} AcpiMemInfo;

extern u8t                *DiskBufPM;      // disk i/o buffer
extern EFI_PHYSICAL_ADDRESS    QSMem;
extern UINTN                 QSPages;

#include "pack2.c"

/** get memory map & (optionally) exit boot services.
    External buffer here should be used to prevent memory changes between
    memory map call & exit boot services.
    @param buffer  64kb buffer for exitbootservices==0 else 128k. */
void int15mem(void *Buf, u32t exitbootservices, u32t *ldrmem, u32t *ldrsize) {
   EFI_MEMORY_DESCRIPTOR *MME,
                   *MemoryMap = (EFI_MEMORY_DESCRIPTOR*)Buf;
   AcpiMemInfo            *ma = (AcpiMemInfo*)DiskBufPM;
   UINTN            NoEntries, DescSize, Size;
   UINTN                   ii;
   EFI_STATUS          Status;

   if (SafeMode && exitbootservices) Print(L"Exiting UEFI services ...\n");
   do {
      UINTN     MapKey;
      UINT32   DescVer;

      Size   = _64KB;
      Status = BS->GetMemoryMap(&Size, Buf, &MapKey, &DescSize, &DescVer);
      /* just a fast panic (should never occur!)
         may be add a normal throw? */
      if (EFI_ERROR(Status)) { ii = 0; ii = DescSize/ii; }

      if (exitbootservices) Status = BS->ExitBootServices(SelfImg, MapKey);
   } while (EFI_ERROR(Status));

   NoEntries = Size/DescSize;

   RtZeroMem(ma, sizeof(AcpiMemInfo)*MEM_LIST_SIZE);

   ma->LengthLow   = 512 * 1024;
   ma->AcpiMemType = 1;

   MME = MemoryMap;
   // leave one entry for zeroed record
   if (NoEntries>MEM_LIST_SIZE-1) NoEntries = MEM_LIST_SIZE-1;

   for (ii=0; ii<NoEntries; ii++) {
      UINT64 blen = MME->NumberOfPages<<EFI_PAGE_SHIFT,
             bend = MME->PhysicalStart + blen;

      if (bend<=640*1024 && bend>ma->LengthLow) ma->LengthLow = (u32t)bend;
         else
      if (MME->PhysicalStart>=_1MB) {
         ma++;
         ma->BaseAddrLow  = (u32t)(MME->PhysicalStart);
         ma->BaseAddrHigh = (u32t)(MME->PhysicalStart>>32);
         ma->LengthLow    = (u32t)blen;
         ma->LengthHigh   = (u32t)(blen>>32);

         if (MME->PhysicalStart<=QSMem && MME->PhysicalStart+blen>QSMem) {
            // QSINIT block can be returned as a part of common "EfiLoaderData"
            u32t qslen = (u32t)(QSPages<<EFI_PAGE_SHIFT);

            if (MME->PhysicalStart<QSMem) {
               ma->LengthLow   = (u32t)(QSMem - MME->PhysicalStart);
               ma->LengthHigh  = 0;
               ma->AcpiMemType = 6;
               blen -= ma->LengthLow;
               ma++;
               ma->BaseAddrLow  = (u32t)QSMem;
            }
            if (qslen>blen) {
               qslen = (u32t)blen;
               log_it(0, L"We have a problem in memory table!\n");
            }
            /* QSINIT block - returned as FREE memory to not confuse
               something in START module */
            ma->LengthLow   = qslen;
            ma->AcpiMemType = 1; 
            blen -= qslen;
            // EfiLoaderData present above QSINIT block
            if (blen) {
               ma++;
               ma->BaseAddrLow  = (u32t)(QSMem + qslen);
               ma->LengthLow    = (u32t)blen;
               ma->AcpiMemType = 6;
            }
         } else
         switch (MME->Type) {
            case EfiReservedMemoryType     :
            case EfiMemoryMappedIO         :
            case EfiMemoryMappedIOPortSpace:
            case EfiPalCode                : ma->AcpiMemType = 2; break;
            case EfiBootServicesCode       :
            case EfiBootServicesData       :
            case EfiLoaderCode             :
            case EfiLoaderData             :
               /* not care about adjacent blocks because meminit.c in
                  OS2LDR able to merge it */
               if (exitbootservices) { ma->AcpiMemType = 1; break; }
            case EfiRuntimeServicesCode    :
            case EfiRuntimeServicesData    : ma->AcpiMemType = 6; break;
            case EfiConventionalMemory     : ma->AcpiMemType = 1; break;
            case EfiUnusableMemory         : ma->AcpiMemType = 5; break;
            case EfiACPIReclaimMemory      : ma->AcpiMemType = 3; break;
            case EfiACPIMemoryNVS          : ma->AcpiMemType = 4; break;
            default:
                ma->AcpiMemType = 2;
         }
      }
      MME = NextMemoryDescriptor(MME, DescSize);
   }
   if (exitbootservices) ReplaceGDT(Buf);
   if (ldrmem) *ldrmem = (u32t)QSMem;
   if (ldrsize) *ldrsize = (u32t)QSPages<<12;
}

void exit_poweroff(u32t actiontype) {
   RT->ResetSystem(actiontype, EFI_SUCCESS, 0, 0);
}
