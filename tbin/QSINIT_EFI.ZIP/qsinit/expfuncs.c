//
// QSINIT EFI loader
// export table for 32-bit code & some misc functions
//
#include "qsloader.h"
#include "efilib.h"
#include "stdio.h"

#define MEM_LIST_SIZE   512

// exports to 32-bit code
void *FuncTable[EFN_FUNCCOUNT] = { tm_calibrate, key_read, key_wait, 
   tm_counter, tm_getdate, tm_setdate, mfs_open, mfs_read, mfs_close,
   mfs_term, key_status, key_pressed, vio_charout, vio_strout,
   vio_clearscr, vio_setpos, vio_getpos, vio_setcolor, vio_getmode,
   vio_setmode, int15mem, vio_showcursor, exit_poweroff, vio_enummodes,
   grf_enummodes, vio_setmodeex, grf_setmode, grf_blit, grf_clear, dsk_io,
   hlp_setreg, XcptOn, hlp_memmove };

u32t         FuncCount = EFN_FUNCCOUNT;

typedef struct _AcpiMemInfo {
   u32t           BaseAddrLow;              ///< base address
   u32t          BaseAddrHigh;
   u32t             LengthLow;              ///< length in bytes
   u32t            LengthHigh;
   u32t           AcpiMemType;              ///< block type
} AcpiMemInfo;

extern u8t                *DiskBufPM;      // disk i/o buffer
extern EFI_PHYSICAL_ADDRESS    QSMem;
extern UINTN                 QSPages;

#include "pack2.c"

void int15mem(void) {
   EFI_MEMORY_DESCRIPTOR    *MME,
                      *MemoryMap;
   UINTN               NoEntries;
   UINTN                  MapKey;
   UINTN                DescSize;
   UINT32                DescVer;
   UINTN                      ii;

   AcpiMemInfo *ma = (AcpiMemInfo*)DiskBufPM;
   RtZeroMem(ma, sizeof(AcpiMemInfo)*MEM_LIST_SIZE);

   ma->LengthLow   = 512 * 1024;
   ma->AcpiMemType = 1;

   MemoryMap = LibMemoryMap(&NoEntries, &MapKey, &DescSize, &DescVer);
   if (MemoryMap) {
      MME = MemoryMap;
      // leave one entry for zeroed record
      if (NoEntries>MEM_LIST_SIZE-1) NoEntries = MEM_LIST_SIZE-1;

      for (ii=0; ii<NoEntries; ii++) {
         UINT64 blen = MME->NumberOfPages<<EFI_PAGE_SHIFT,
                bend = MME->PhysicalStart + blen;

         if (bend<=640*1024 && bend>ma->LengthLow) ma->LengthLow = (u32t)bend;
            else
         if (MME->PhysicalStart>=_1MB) {
            ma++;
            ma->BaseAddrLow  = (u32t)(MME->PhysicalStart);
            ma->BaseAddrHigh = (u32t)(MME->PhysicalStart>>32);
            ma->LengthLow    = (u32t)blen;
            ma->LengthHigh   = (u32t)(blen>>32);

            if (MME->PhysicalStart<=QSMem && MME->PhysicalStart+blen>QSMem) {
               // QSINIT block can be returned as a part of common "EfiLoaderData"
               u32t qslen = (u32t)(QSPages<<EFI_PAGE_SHIFT);

               if (MME->PhysicalStart<QSMem) {
                  ma->LengthLow   = (u32t)(QSMem - MME->PhysicalStart);
                  ma->LengthHigh  = 0;
                  ma->AcpiMemType = 6;
                  blen -= ma->LengthLow;
                  ma++;
                  ma->BaseAddrLow  = (u32t)QSMem;
               }
               if (qslen>blen) {
                  qslen = (u32t)blen;
                  log_it(0, L"We have a problem in memory table!\n");
               }
               /* QSINIT block - returned as FREE memory to not confuse
                  something in START module */
               ma->LengthLow   = qslen;
               ma->AcpiMemType = 1; 
               blen -= qslen;
               // EfiLoaderData present above QSINIT block
               if (blen) {
                  ma++;
                  ma->BaseAddrLow  = (u32t)(QSMem + qslen);
                  ma->LengthLow    = (u32t)blen;
                  ma->AcpiMemType = 6;
               }
            } else
            switch (MME->Type) {
               case EfiReservedMemoryType     :
               case EfiMemoryMappedIO         :
               case EfiMemoryMappedIOPortSpace:
               case EfiPalCode                : ma->AcpiMemType = 2; break;
               case EfiLoaderCode             :
               case EfiLoaderData             :
               case EfiBootServicesCode       :
               case EfiBootServicesData       :
               case EfiRuntimeServicesCode    :
               case EfiRuntimeServicesData    : ma->AcpiMemType = 6; break;
               case EfiConventionalMemory     : ma->AcpiMemType = 1; break;
               case EfiUnusableMemory         : ma->AcpiMemType = 5; break;
               case EfiACPIReclaimMemory      : ma->AcpiMemType = 3; break;
               case EfiACPIMemoryNVS          : ma->AcpiMemType = 4; break;
               default:
                   ma->AcpiMemType = 2;
            }
         }
         MME = NextMemoryDescriptor(MME, DescSize);
      }
      FreePool(MemoryMap);
   }
}

void exit_poweroff(u32t actiontype) {
   RT->ResetSystem(actiontype, EFI_SUCCESS, 0, 0);
}

#if 0
int log_it(int level, CHAR16 *fmt) {
   char   *cp = (char*)(u64t)Header32->logrmbuf;
   u32t   pos = Header32->logrmpos;

   if (!cp || pos>=LOGBUF_SIZE-5) return 0;
   // level 0..3 and LOGIF_DELAY+LOGIF_REALMODE flags
   level = level&3|0x30;
   /* if there is no EOL at the end of last entry - appends this line to it,
      else starts a new entry */
   if (!pos || cp[pos-1]=='\n') {
      if (pos) pos++;
      cp[pos++] = (u8t)level;
   }
   while (pos<LOGBUF_SIZE-1)
      if (*fmt=='\n') fmt++; else
         if ((cp[pos] = (char)*fmt++)==0) break; else pos++;
   // logrmpos must point to the term NULL in the last string!
   Header32->logrmpos = (u16t)pos;

   //hlp_seroutstr(cp+pos);
   return 1;
}
#endif
