//
// QSINIT EFI loader
// 32-bit part decompression
//
#include "qsloader.h"

#define STATIC_BUFFERS       0  // use static huffman tree arrays
#define MAXFREQ           2000  // max frequency count before table reset
#define MINCOPY              3  // shortest string copy length
#define MAXCOPY             66  // longest string copy length
#define COPYRANGES           7  // number of string copy distance bit ranges
#define CODESPERRANGE      (MAXCOPY - MINCOPY + 1)
#define CODESPERRANGE_SHIFT  6  // CODESPERRANGE made a power of 2
// Adaptive Huffman variables
#define TERMINATE          256  // EOF code
#define FIRSTCODE          257  // first code for copy lengths
#define SIX_MAXCHAR        (FIRSTCODE+COPYRANGES*CODESPERRANGE-1)
#define SUCCMAX            (SIX_MAXCHAR+1)
#define TWICEMAX           (2*SIX_MAXCHAR+1)
#define ROOT                 1
#define MAXSIZE          32768

const int CopyBits[COPYRANGES] = {4,6,8,10,12,14,14}, // distance bits
           CopyMin[COPYRANGES] = {0,16,80,320,1024,4096,16384};

#if STATIC_BUFFERS
static s16t         LeftC[SIX_MAXCHAR+1],
                   RightC[SIX_MAXCHAR+1];
static s16t        Parent[TWICEMAX+1],
                     Freq[TWICEMAX+1];
u32t         unpackMemReq = MAXSIZE + 4;
#else
#define DArrayType s16t
static DArrayType  *LeftC, *RightC, *Parent, *Freq;
u32t         unpackMemReq = MAXSIZE + 4 + 
                            Round16((SIX_MAXCHAR+1) * sizeof(DArrayType)) * 2 +
                            Round16((TWICEMAX+1) * sizeof(DArrayType)) * 2;
#endif
static u8t*        CurBuf;
static s32t     bit_count;
static s32t    bit_buffer;

static void Update_Freq(s32t aa, s32t bb) {
   do {
      Freq[Parent[aa]]=Freq[aa]+Freq[bb];
      aa = Parent[aa];
      if (aa!=ROOT) 
         bb = LeftC[Parent[aa]]==aa ? RightC[Parent[aa]] : LeftC[Parent[aa]];
   } while (aa!=ROOT);
   if (Freq[ROOT]==MAXFREQ)
      for (aa=1; aa<=TWICEMAX; aa++) Freq[aa]>>=1;
}

static void Update_Model(s32t Code) {
   s32t aa = Code+SUCCMAX, ua;

   ++Freq[aa];
   if (Parent[aa]!=ROOT) {
      ua = Parent[aa];
      Update_Freq(aa, LeftC[ua]==aa?RightC[ua]:LeftC[ua]);
      do {
         s32t uua = Parent[ua],
               bb = LeftC[uua]==ua?RightC[uua]:LeftC[uua], cc;
         if (Freq[aa]>Freq[bb]) {
            if (LeftC[uua]==ua) RightC[uua]=aa; else LeftC[uua]=aa;
            if (LeftC[ua]==aa) { LeftC[ua]=bb; cc=RightC[ua]; }
               else { RightC[ua]=bb; cc=LeftC[ua]; }
            Parent[bb]=ua;
            Parent[aa]=uua;
            Update_Freq(bb,cc);
            aa = bb;
         }
         aa = Parent[aa];
         ua = Parent[aa];
      } while (ua!=ROOT);
   }
}

#define ReadBit(action) {          \
   if (!bit_count) {               \
      bit_buffer=*(u32t*)Source;   \
      Source+=4;                   \
      bit_count=31;                \
   } else bit_count--;             \
   action;                         \
   bit_buffer<<=1;                 \
}

u32t decompress(u32t Length, u8t *Source, u8t *Destin, u8t* Buffer) {
   s32t  ii, J, Dist, Len, index, K, T,
         outc = 0, cc;
 
   bit_count=0; bit_buffer=0; CurBuf=Destin;
    // 19800000 - static s16, 22x00000 - dynamic s32
#if !STATIC_BUFFERS
   LeftC  = (DArrayType*)Buffer;
   RightC = (DArrayType*)(Buffer += Round16((SIX_MAXCHAR+1) * sizeof(DArrayType)));
   Parent = (DArrayType*)(Buffer += Round16((SIX_MAXCHAR+1) * sizeof(DArrayType)));
   Freq   = (DArrayType*)(Buffer += Round16((TWICEMAX+1) * sizeof(DArrayType)));
   Buffer += Round16((TWICEMAX+1) * sizeof(DArrayType));
#endif
   for (ii=2;ii<=TWICEMAX;ii++) { Parent[ii]=ii>>1; Freq[ii]=1; }
   for (ii=1;ii<=SIX_MAXCHAR;ii++) { LeftC[ii]=ii<<1; RightC[ii]=(ii<<1)+1; }
 
   while (1) {
      cc = 1;
      do {
         ReadBit(cc = bit_buffer<0?RightC[cc]:LeftC[cc]);
      } while (cc<=SIX_MAXCHAR);
      cc -= SUCCMAX;
      Update_Model(cc);
      if (cc==TERMINATE) break;

      if (cc<256) { // single literal?
         *CurBuf++=cc;
         Buffer[outc]=cc; if (++outc==MAXSIZE) outc=0;
      } else {     // else string copy length/distance codes
         T     = cc - FIRSTCODE;
         index = T>>CODESPERRANGE_SHIFT;
         Len   = T + MINCOPY - index*CODESPERRANGE;
         Dist  = 0;
         for (ii=0; ii<CopyBits[index]; ii++) {
            ReadBit(if (bit_buffer<0) Dist|=1<<ii);
         }
         Dist += Len+CopyMin[index];
         J = outc;
         K = outc - Dist;
         if (K<0) K+=MAXSIZE;
         for (ii=0; ii<Len; ii++) {
            *CurBuf++ = Buffer[K];
            Buffer[J] = Buffer[K];
            if (++J==MAXSIZE) J=0;
            if (++K==MAXSIZE) K=0;
         }
         outc+=Len;
         if (outc>=MAXSIZE) outc-=MAXSIZE;
      }
   }
   return (u32t)(CurBuf-Destin);
}
