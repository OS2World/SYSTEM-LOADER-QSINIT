//
// QSINIT
// test loader
//
#ifndef QS_EFI_LOADER
#define QS_EFI_LOADER

#pragma warning(disable:4554)  // disable warning about shift presedence

#include "efi.h"

typedef UINT64          u64t;
typedef INT64           s64t;
typedef UINT32          u32t;
typedef INT32           s32t;
typedef UINT16          u16t;
typedef INT16           s16t;
typedef UINT8            u8t;
typedef INT8             s8t;

#include "efnlist.h"
#include "qsexp.h"

#define PAGESHIFT    (12)
#define PAGESIZE     (0x1000)
#define PAGEMASK     (0x0FFF)
#define PARASHIFT    (4)

#define FFFF         (0xFFFFFFFF)
#define x7FFF        (0x7FFFFFFF)
#define x7FFF64      (((s64t)(0x7FFFFFFF)<<32)+0xFFFFFFFF)
#define FFFF64       (((u64t)(0xFFFFFFFF)<<32)+0xFFFFFFFF)

#define   _1KB       (  1UL* 1024)       // 1 kb
#define  _64KB       ( 64UL* _1KB)       // 64 kb
#define   _1MB       ( _1KB* _1KB)       // 1 mb
#define  _16MB       ( 16UL* _1MB)       // 16 mb
#define  _32MB       ( 32UL* _1MB)       // 16 mb
#define  _64MB       ( 64UL* _1MB)       // 64 mb
#define _512MB       (512UL* _1MB)       // 512 mb
#define _4GBLL       ((u64t)0xFFFFFFFF+1)    // 4 gb (64 bit)
#define _2TBLL       ((u64t)0xFFFFFFFF+1<<9) // 2 tb (64 bit)

#define PAGEROUND(p)    (((p) + PAGEMASK) & ~PAGEMASK)
#define PAGEROUNDLL(p)  (((p) + PAGEMASK) & ~(u64t)PAGEMASK)

#define Round2(ii)   (((ii)+1)&0xFFFFFFFE)
#define Round4(ii)   (((ii)+3)&0xFFFFFFFC)
#define Round8(ii)   (((ii)+7)&0xFFFFFFF8)
#define Round16(ii)  (((ii)+0x0F)&0xFFFFFFF0)
#define Round32(ii)  (((ii)+0x1F)&0xFFFFFFE0)
#define Round64(ii)  (((ii)+0x3F)&0xFFFFFFC0)
#define Round128(ii) (((ii)+0x7F)&0xFFFFFF80)
#define Round256(ii) (((ii)+0xFF)&0xFFFFFF00)
#define Round512(ii) (((ii)+0x1FF)&0xFFFFFE00)
#define Round1k(ii)  (((ii)+0x3FF)&0xFFFFFC00)
#define Round2k(ii)  (((ii)+0x7FF)&0xFFFFF800)
#define Round4k(ii)  (((ii)+0xFFF)&0xFFFFF000)
#define Round64k(ii) (((ii)+0xFFFF)&0xFFFF0000)

#define Xor(v1,v2)    (((v1)?1:0)^((v2)?1:0))

/* key_status() bits, just copied here from QSINIT`s vio.h, because qsinit, 
   at last, able to receive only what we know here ;) */
#define KEY_SHIFT       0x000001
#define KEY_ALT         0x000002
#define KEY_CTRL        0x000004
#define KEY_NUMLOCK     0x000008
#define KEY_CAPSLOCK    0x000010
#define KEY_SCROLLLOCK  0x000020
#define KEY_SHIFTLEFT   0x000040
#define KEY_SHIFTRIGHT  0x000080
#define KEY_CTRLLEFT    0x000100
#define KEY_CTRLRIGHT   0x000200
#define KEY_ALTLEFT     0x000400
#define KEY_ALTRIGHT    0x000800
#define KEY_SYSREQ      0x001000
#define KEY_INSERT      0x002000

void key_init(void);
u16t key_read(void);
u16t key_wait(u32t seconds);
u32t key_status(void);
u8t  key_pressed(void);
u16t tm_calibrate(void);
u32t tm_counter(void);
u64t tm_getdate(void);
void tm_setdate(u32t dostime);
u16t mfs_open (u32t plen);
u32t mfs_read (u32t offset, u32t buf, u32t readsize);
u32t mfs_close(void);
u32t mfs_term (void);
u32t vio_charout(u8t ch);
u32t vio_strout(const char *str);
void vio_clearscr(void);
void vio_setpos(u32t line, u32t col);
void vio_getpos(u32t *line, u32t *col);
void vio_setcolor(u16t color);
u8t  vio_getmode(u32t *cols, u32t *lines);
void vio_init(void);
void vio_setmode(u32t lines);
void vio_conlock(int lock);
int  vio_setmodeex(u32t cols, u32t lines);
void vio_showcursor(u32t state);
u32t vio_enummodes(struct console_mode **mi);
u32t grf_enummodes(struct graphic_mode **mi, u32t *vmemptr, u32t *vmemsize);
u32t grf_setmode(u32t mode);
u32t grf_blit(u32t x, u32t y, u32t dx, u32t dy, void *buf, u32t pitch);
u32t grf_clear(u32t x, u32t y, u32t dx, u32t dy, u32t color);
void vio_term(void);
u32t dsk_init(exp32_table *etab, struct qs_diskinfo *qdd);
u32t dsk_io(struct qs_diskinfo *di, u64t start, u32t sectors, u32t writeflag);
void dsk_term(void);
void int15mem(void);
void exit_poweroff(u32t actiontype);
u64t hlp_setreg(u32t idx, u64t value);
void hlp_memmove(void *dst, void *src, u64t length);

int  Load32(void);
u32t Exec32(void);
void ErrorExit(CHAR16 *msg);
void IntsOn(void);
void IntsOff(void);
u16t GetCodeSelector(void);

u32t XcptOn(void);

s32t bsf64(u64t value);
s32t bsr64(u64t value);

u64t ReadTSC(void);

/** push string into QSINIT log
    @param level   log level = 0..3
    @param fmt     format - in EFI Lib Print() syntax */
int  log_it(int level, CHAR16 *fmt, ...);

/** dump handle protocols to QSINIT log
    @param info    short header info (without EOL)
    @param eh      handle */
void DumpHandleProtocols(const CHAR16 *info, EFI_HANDLE *eh);

/// allocate pages
EFI_PHYSICAL_ADDRESS PageAlloc(u32t pages);

/// stricmp for A..Z chars
int  RtStrICmp(const CHAR16 *s1, const CHAR16 *s2);

extern exp32_table *Header32;

#endif // QS_EFI_LOADER
