//
// QSINIT EFI loader
// main() function
//
#include "qsloader.h"
#include "efilib.h"
#include "pe.h"
#include "seldesc.h"

#define RESERVE_DESCRIPTORS    256
#define PRINT_MEM_TABLE        0
#define XCPT_STACK_SIZE        (96*1024)

#pragma pack(1)
typedef struct {
   UINT16                limit;
   EFI_PHYSICAL_ADDRESS   base;
} GDT64;
#pragma pack()

void ReadGDTR       (GDT64 *Gdt);
void WriteGDTR      (GDT64 *Gdt);
void ReadIDTR       (GDT64 *Gdt);
void SaveSegRegs    (void);
void RestSegRegs    (void);

static EFI_HANDLE       SelfImg = 0;
static GDT64           SavedGDT,
                         CurGDT,
                         CurIDT;
u64t                   SavedCr4;
u32t*                     lapic = 0;       // non-zero only in MT mode
u32t                   SavedSpr = 0;
EFI_PHYSICAL_ADDRESS    GDTCopy = 0;       // own GDT :)
UINT32                  GDTSize = 0,       // size of GDT in bytes
                      GDTLowest = 0;       // lowest usable selector
EFI_PHYSICAL_ADDRESS      QSMem = 0;       // memory for QSINIT
UINTN                   QSPages = 0;       // size of it in pages
EFI_LOADED_IMAGE   *LoadedImage = 0;
EFI_DEVICE_PATH     *DevicePath = 0;
UINT32                  UGAOnly = 0;
UINT32                 SafeMode = 0;
struct gate64_s      *SavedIDTv = 0;
void                 *XcptStack = 0;
extern u64t        trap_table[];

static UINT8      int_used[256];           // "vector was changed" flag

#if PRINT_MEM_TABLE > 0
static CHAR16  *MemTypeStr[EfiMaxMemoryType]  = {
            L"reserved  ",
            L"LoaderCode",
            L"LoaderData",
            L"BS_code   ",
            L"BS_data   ",
            L"RT_code   ",
            L"RT_data   ",
            L"available ",
            L"Unusable  ",
            L"ACPI_recl ",
            L"ACPI_NVS  ",
            L"MemMapIO  ",
			L"MemPortIO ",
			L"PAL_code  "
    };
#endif

extern void timer_irq(void);
extern void iretq_addr(void);

void ErrorExit(CHAR16 *msg) {
   mfs_term();
   vio_term();
   // here we get back EFI console
   Print(msg);
   dsk_term();
   // restore GDT
   if (GDTCopy) {
      GDT64  cGDT;
      ReadGDTR(&cGDT);
      Print (L"GDT base: %X, size %X\n", cGDT.base, cGDT.limit+1);
      // if GDT is ours - restore original
      if (cGDT.base==GDTCopy) {
         RestSegRegs();
         WriteGDTR(&SavedGDT);
         Print (L"GDT restored\n");
      }
      // if GDT is ours or restored by someone - free our`s GDT buffer
      if (cGDT.base==GDTCopy || cGDT.base==SavedGDT.base)
         BS->FreePages(GDTCopy, Round4k(GDTSize)>>12);
   }
   // free QSINIT memory space if allocated
   if (QSMem) BS->FreePages(QSMem, QSPages);
   // return to EFI shell/boot sequence
   BS->Exit(SelfImg, EFI_SUCCESS, 0, NULL);
}

void init_memory(void) {
   EFI_STATUS             Status;
   EFI_MEMORY_DESCRIPTOR    *MME,
                      *MemoryMap;
   UINTN               NoEntries;
   UINTN                  MapKey;
   UINTN                DescSize;
   UINT32                DescVer;
   EFI_PHYSICAL_ADDRESS    RcMem = 0;
   UINTN                 RcPages = 0, 
                       MaxContig = 0;
   UINTN               TotalFree = 0;
   UINTN                      ii;

   MemoryMap = LibMemoryMap(&NoEntries, &MapKey, &DescSize, &DescVer);
   if (!MemoryMap) ErrorExit(L"Can not retrieve the current memory map\n");

#if PRINT_MEM_TABLE > 0
   Print(L"Memory Descriptor List:\n\n");
   Print(L"  Type        Start Address     End Address       Attributes      \n");
   Print(L"  ==========  ================  ================  ================\n");
#endif
   MME = MemoryMap;
   // calculate number of free pages below 4Gb & max contigous block size
   for(ii=0; ii<NoEntries; ii++) {
      if (MME->Type==EfiConventionalMemory && MME->PhysicalStart>=_1MB &&
         MME->PhysicalStart<_4GBLL) 
      {
         TotalFree+=MME->NumberOfPages;
         if (MME->NumberOfPages>MaxContig) MaxContig = MME->NumberOfPages;
      }
#if PRINT_MEM_TABLE > 0
      Print(L"  %s  %X  %X  %X\n", MemTypeStr[MME->Type], MME->PhysicalStart,
            MME->PhysicalStart+(MME->NumberOfPages<<EFI_PAGE_SHIFT)-1, MME->Attribute);
#endif
      MME = NextMemoryDescriptor(MME, DescSize);
   }

   MME = MemoryMap;
   for(ii=0; ii<NoEntries; ii++) {
      if (MME->Type==EfiConventionalMemory && MME->PhysicalStart>=_1MB &&
         MME->PhysicalStart<_4GBLL && MME->NumberOfPages<<EFI_PAGE_SHIFT>=_32MB)
      {
         RcPages = MME->NumberOfPages;
         RcMem   = MME->PhysicalStart;
         /* if block larger 512Mb or 2/3 of all available memory - use 2/3 of it */
         if (RcPages>_512MB>>PAGESHIFT || RcPages>TotalFree-TotalFree/3 ) RcPages = RcPages*2/3;
   
         Status = BS->AllocatePages(AllocateAddress, EfiLoaderData, RcPages, &RcMem);
         if (EFI_ERROR(Status)) RcMem = 0; else break;
      }
      MME = NextMemoryDescriptor(MME, DescSize);
   }
   /* failed to allocate at lowest address? then try to use:
      1. 2/3 of max contigous below 4Gb
      2. 32Mb below 4Gb
      3. 32Mb anywhere */
   if (!RcMem) {
      for (ii=0; ii<3; ii++) {
         RcMem   = FFFF & ~PAGEMASK;
         RcPages = ii ? _32MB>>EFI_PAGE_SHIFT : MaxContig*2/3;

         Status  = BS->AllocatePages(ii<2?AllocateMaxAddress:AllocateAnyPages,
            EfiLoaderData, RcPages, &RcMem);
         if (!EFI_ERROR(Status)) break; else RcMem = 0;
      }
   }
   FreePool(MemoryMap);
   // check result
   if (!RcMem || RcPages < _32MB>>EFI_PAGE_SHIFT) ErrorExit(L"No 32Mb of free memory!\n");
   if (RcMem>=_4GBLL) ErrorExit(L"Unable to allocate memory below 4Gb!\n");
   // finally, we got it!
   if (RcMem && RcPages) {
      QSMem   = RcMem;
      QSPages = RcPages;
   }
}


EFI_PHYSICAL_ADDRESS PageAlloc(u32t pages) {
   EFI_PHYSICAL_ADDRESS Addr = FFFF & ~PAGEMASK;
   EFI_STATUS         Status = BS->AllocatePages(AllocateMaxAddress, EfiLoaderData, 
                                                 pages, &Addr);
   if (EFI_ERROR(Status)) ErrorExit(L"Memory allocation error!\n");
   return Addr;
}

u32t XcptOn(void) {
   if (!SafeMode) {
      struct gate64_s *idesc = (struct gate64_s *)CurIDT.base;
      u16t cs64 = GetCodeSelector();
      int    ii = 0;

      IntsOff();
      while (trap_table[ii]!=FFFF64) {
         u64t inta = trap_table[ii];
         if (inta) {
            idesc->g64_sel    = cs64;
            idesc->g64_ofs0   = (u16t)inta;
            idesc->g64_ofs16  = (u16t)(inta>>16);
            idesc->g64_ofs32  = (u32t)(inta>>32);
            idesc->g64_parms  = 0;
            idesc->g64_access = D_PRES|D_TRAPGATE32;
            // mark it to restore
            int_used[ii] = 1;
         }
         ii++;
         idesc++;
      }
      IntsOn();
      return 1;
   }
   return 0;
}

u32t TimerIrqsOn(u32t* apic, u8t tmr_vector, u8t spr_vector) {
   if (tmr_vector<16 || spr_vector<16) return 0; else {
      u16t cs64 = GetCodeSelector();
      int    ii;

      IntsOff();
      lapic    = apic;
      SavedSpr = apic[APIC_SPURIOUS];

      for (ii=0; ii<2; ii++) {
         u32t   vn = ii?spr_vector:tmr_vector;
         u64t inta = (u64t)(ii?&iretq_addr:&timer_irq);
         struct gate64_s *idesc = (struct gate64_s *)CurIDT.base + vn;
         idesc->g64_sel    = cs64;
         idesc->g64_ofs0   = (u16t)inta;
         idesc->g64_ofs16  = (u16t)(inta>>16);
         idesc->g64_ofs32  = (u32t)(inta>>32);
         idesc->g64_parms  = 0;
         idesc->g64_access = D_PRES|D_INTGATE32;
         // mark it to restore
         int_used[vn] = 1;
      }
      IntsOn();

      return 1;
   }
}

void RestoreIDT(void) {
   struct gate64_s *idesc = (struct gate64_s *)CurIDT.base;
   int  ii;

   IntsOff();
   for (ii=0; ii<256; ii++)
      if (int_used[ii]) idesc[ii] = SavedIDTv[ii];
   IntsOn();
}

// "main" function
void QSLoader(IN EFI_HANDLE ImgHandle, IN EFI_SYSTEM_TABLE *SysTab) {
   EFI_STATUS   st;
   UINTN        ii;
   // Initialize the Library. Set BS, RT, &ST globals
   //  BS = Boot Services RT = RunTime Services
   //  ST = System Table
   InitializeLib (ImgHandle, SysTab);

   SelfImg = ImgHandle;
   // save and replace GDT 
   ReadGDTR(&SavedGDT);

   if (0xFFFF - SavedGDT.limit < RESERVE_DESCRIPTORS * 8)
      ErrorExit(L"There is no space in System GDT, unable to run!\n");
   // who can allocate above 4Gb? still care
   GDTSize = SavedGDT.limit + 1 + RESERVE_DESCRIPTORS * 8;
   GDTCopy = PageAlloc(Round4k(GDTSize + sizeof(struct gate64_s)*256 + XCPT_STACK_SIZE)>>12);
   // makes a copy of original GDT
   RtZeroMem((void*)GDTCopy, GDTSize);
   RtCopyMem((void*)GDTCopy, (void*)SavedGDT.base, GDTLowest = SavedGDT.limit + 1);

   RtZeroMem(&int_used, sizeof(int_used));

   SavedIDTv = (struct gate64_s *)(GDTCopy + GDTSize);
   // points to the end of block
   XcptStack = (u8t*)(SavedIDTv + 256) + XCPT_STACK_SIZE;

   CurGDT.base  = GDTCopy;
   CurGDT.limit = GDTSize - 1;

   SaveSegRegs();
   WriteGDTR(&CurGDT);
#if PRINT_MEM_TABLE > 0
   Print(L"GDT base: %X, size %X\n", GDTCopy, GDTSize);
#endif
   BS->SetWatchdogTimer(0, 0, 0, 0);

   // Get the device handle and file path to the EFI OS Loader itself.
   st = BS->HandleProtocol(ImgHandle, &LoadedImageProtocol, (VOID*)&LoadedImage);
   if (EFI_ERROR(st))
      ErrorExit(L"Can not retrieve a LoadedImageProtocol handle for ImageHandle\n");

   st = BS->HandleProtocol(LoadedImage->DeviceHandle, &DevicePathProtocol, (VOID*)&DevicePath);
   if (EFI_ERROR(st) || DevicePath==NULL)
      ErrorExit(L"Can not find a DevicePath handle for LoadedImage\n");

   // primitive command line parser
   if (LoadedImage->LoadOptionsSize) {
	  CHAR16 *cmdline = LoadedImage->LoadOptions,
	             nopt[32];
	  UINT32  ii, optc = 0;

	  for (ii=0; ii<LoadedImage->LoadOptionsSize; ii++)
	     if (cmdline[ii]<=' ') {
	        if (optc) {
	           nopt[optc] = 0;
	           if (RtStrICmp(nopt,L"/UGA")==0) UGAOnly = 1; else
	           if (RtStrICmp(nopt,L"/SM")==0) SafeMode = 1;
	           optc = 0;
	        }
	        if (!cmdline[ii]) break;
	     } else
	     if (optc<31) nopt[optc++] = cmdline[ii];
   }
   // init keyboard
   key_init();
   // init console
   vio_init();
   // calculate "timer" ticks
   tm_counter();
   // find place to place 32-bit part ;)
   init_memory();
#if PRINT_MEM_TABLE > 0
   Print(L"  QSINIT memory at address                   : %X\n", QSMem);
   Print(L"         size in kb                          : %ld\n", ((u64t)QSPages<<PAGESHIFT)>>10);

   Print(L"\nPress ENTER to continue...\n");
   {
      u32t key;
      do {
         key = key_read();
         Print (L"Key Code : %X\n", key);
      } while ((key&0xFF) != 13);
   } 
#endif
   if (!SafeMode) {
      // check for key at least once and hope it will return LEFT SHIFT for us ;)
      key_pressed();
      if (key_status()&KEY_SHIFTLEFT) SafeMode = 1;
   }
   // save IDT
   ReadIDTR(&CurIDT);
   RtCopyMem(SavedIDTv, (void*)CurIDT.base, sizeof(struct gate64_s)*256);
   // save CR4
   SavedCr4 = hlp_setreg(4, FFFF64);

   ii = Load32();
   if (ii) Print(L"Load32() rc = %d\n",ii);
   ii = SysConfig();
   if (ii) Print(L"SysConfig() rc = %d\n",ii);
   ii = Exec32();
   // restore APIC
   if (lapic) {
      IntsOff();
      lapic[APIC_LVT_TMR]  = APIC_DISABLE;
      lapic[APIC_SPURIOUS] = SavedSpr;
      IntsOn();
   }
   if (ii) Print(L"Exec32() rc = %d\n",ii);
   
   RestoreIDT();
   // restore cr4
   hlp_setreg(4, SavedCr4);

   ErrorExit(L"Bye!\n");
}
