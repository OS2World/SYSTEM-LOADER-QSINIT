//
// QSINIT EFI loader
// system data management
//
#include "qsloader.h"
#include "efilib.h"

#define SMBIOS3_TABLE_GUID \
   {0xf2fd1544, 0x9794, 0x4a2c, {0x99,0x2e,0xe5,0xbb,0xcf,0x20,0xe3,0x94}}
#define EFI_PROPERTIES_TABLE_GUID \
   {0x880aaca3, 0x4adc, 0x4a04, {0x90,0x79,0xb7,0x47,0x34,0x8,0x25,0xe5}}
#define EFI_SYSTEM_RESOURCES_TABLE_GUID \
   {0xb122a263, 0x3661, 0x4f68, {0x99,0x29,0x78,0xf8,0xb0,0xd6,0x21,0x80}}
#define EFI_SECTION_TIANO_COMPRESS_GUID \
   {0xa31280ad, 0x481e, 0x41b6, {0x95,0xe8,0x12,0x7f,0x4c,0x98,0x47,0x79}}
#define EFI_SECTION_LZMA_COMPRESS_GUID  \
   {0xee4e5898, 0x3914, 0x4259, {0x9d,0x6e,0xdc,0x7b,0xd7,0x94,0x03,0xcf}}
#define EFI_DXE_SERVICES_TABLE_GUID \
   {0x5ad34ba, 0x6f02, 0x4214, {0x95,0x2e,0x4d,0xa0,0x39,0x8e,0x2b,0xb9}}
#define EFI_HOB_LIST_GUID \
   {0x7739f24c, 0x93d7, 0x11d4, {0x9a,0x3a,0x00,0x90,0x27,0x3f,0xc1,0x4d}}
#define MEMORY_TYPE_INFORMATION_GUID \
   {0x4c19049f, 0x4137, 0x4dd3, {0x9c,0x10,0x8b,0x97,0xa8,0x3f,0xfd,0xfa}}
#define EFI_DEBUG_IMAGE_INFO_TABLE_GUID \
   {0x49152e77, 0x1ada, 0x4764, {0xb7,0xa2,0x7a,0xfe,0xfe,0xd9,0x5e,0x8b}}

typedef struct {
   EFI_GUID   guid;
   CHAR16     *str;
} KnownGuid;

#define GTAB_LEN    14

static KnownGuid gtab[GTAB_LEN] = {
   { ACPI_20_TABLE_GUID,  L"ACPI 2.0 table" },
   { ACPI_TABLE_GUID,  L"ACPI 1.0 table" },
   { SAL_SYSTEM_TABLE_GUID,  L"SAL system table" },
   { SMBIOS_TABLE_GUID,  L"SMBIOS table" },
   { SMBIOS3_TABLE_GUID,  L"SMBIOS 3 table" },
   { MPS_TABLE_GUID,  L"MPS table" },
   { EFI_PROPERTIES_TABLE_GUID,  L"EFI properties table" },
   { EFI_SYSTEM_RESOURCES_TABLE_GUID,  L"ESRT table" },
   { EFI_SECTION_TIANO_COMPRESS_GUID,  L"Tiano compress" },
   { EFI_SECTION_LZMA_COMPRESS_GUID, L"LZMA compress" },
   { EFI_DXE_SERVICES_TABLE_GUID, L"DXE services" },
   { EFI_HOB_LIST_GUID, L"HOB list" },
   { MEMORY_TYPE_INFORMATION_GUID, L"Memory type information" },
   { EFI_DEBUG_IMAGE_INFO_TABLE_GUID, L"Debug image info table" }
};

typedef struct {
   EFI_GUID   guid;
   u8t      target;
   u8t       force;
} TableList;

#define TABLE_LEN   5
static TableList sig[TABLE_LEN] = {
   {ACPI_TABLE_GUID,0,0}, {ACPI_20_TABLE_GUID,0,1}, {SMBIOS_TABLE_GUID,1,0},
   {SMBIOS3_TABLE_GUID,2,0}, {MPS_TABLE_GUID,3,0}
};

int SysConfig(void) {
   UINTN   ii, idx;
   int       error = 0;
   Header32->acpitable = 0;
   /* walk over configuration table and read table pointers.
      ACPI 2.0 will replace ACPI 1.0 if both found. */
   for (ii=0; ii<ST->NumberOfTableEntries; ii++)
      for (idx=0; idx<TABLE_LEN; idx++)
         if (!CompareGuid(&ST->ConfigurationTable[ii].VendorGuid,&sig[idx].guid)) {
            u32t *dst = 0;
            u64t addr = (u64t)ST->ConfigurationTable[ii].VendorTable;
            switch (sig[idx].target) {
               case 0: dst = &Header32->acpitable; break;
               case 1: dst = &Header32->smbios;    break;
               case 2: dst = &Header32->smbios3;   break;
               case 3: dst = &Header32->mpstab;    break;
            }
            if (addr>=_4GBLL) error|=1<<sig[idx].target; else
               if (*dst==0 || sig[idx].force) *dst = (u32t)addr;
            break;
         }
   return error;
}

void DumpConfigTable(void) {
   UINTN   ii, idx;
   log_it(1, L"Configuration table (%d entries):\n", ST->NumberOfTableEntries);

   for (ii=0; ii<ST->NumberOfTableEntries; ii++) {
      CHAR16 buf[128], *name = 0;
      GuidToString(buf, &ST->ConfigurationTable[ii].VendorGuid);

      for (idx=0; idx<GTAB_LEN; idx++)
         if (!CompareGuid(&ST->ConfigurationTable[ii].VendorGuid,&gtab[idx].guid)) {
            name = gtab[idx].str;
            break;
         }
      log_it(1, L" [%s] %s\n", buf, name?name:L"");
   }
}
