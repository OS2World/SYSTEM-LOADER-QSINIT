//
// QSINIT EFI loader
// system data management
//
#include "qsloader.h"
#include "efilib.h"

typedef struct {
   EFI_GUID   guid;
   u8t      target;
   u8t       force;
} TableList;

#define TABLE_LEN   3

static TableList sig[TABLE_LEN] =
  {{ACPI_TABLE_GUID, 0, 0}, {ACPI_20_TABLE_GUID, 0, 1}, {SMBIOS_TABLE_GUID, 1, 0}};

int SysConfig(void) {
   UINTN   ii, idx;
   u32t    smtable = 0;
   int       error = 0;
   Header32->acpitable = 0;
   /* walk over configuration table and read table pointers.
      ACPI 2.0 will replace ACPI 1.0 if both found.
      There is no SM BIOS table in modern UEFI, but it here just as an example ;) */
   for (ii=0; ii<ST->NumberOfTableEntries; ii++)
      for (idx=0; idx<TABLE_LEN; idx++)
         if (!CompareGuid(&ST->ConfigurationTable[ii].VendorGuid,&sig[idx].guid)) {
            u32t *dst = sig[idx].target?&smtable:&Header32->acpitable;
            u64t addr = (u64t)ST->ConfigurationTable[ii].VendorTable;

            if (addr>=_4GBLL) error|=1<<sig[idx].target; else
               if (*dst==0 || sig[idx].force) *dst = (u32t)addr;
            break;
         }
   return error;
}
