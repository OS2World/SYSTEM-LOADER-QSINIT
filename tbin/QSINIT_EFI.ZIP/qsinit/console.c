//
// QSINIT EFI loader
// console & graphics management
//
#include "qsloader.h"
#include "efilib.h"
#include "graphex.h"
#include "conctrl.h"

static 
struct console_mode    *con_modeinfo = 0;
static u32t                con_modes = 0;
static 
struct graphic_mode    *grf_modeinfo = 0;
static u32t                grf_modes = 0;

static u32t                    modex = 80,
                               modey = 25;
static INT32                  mode25 = -1,
                              mode43 = -1,
                              mode50 = -1;

EFI_GUID                GraphOutGuid = EFI_GRAPHICS_OUTPUT_PROTOCOL_GUID;
EFI_GUID                 ConCtrlGuid = EFI_CONSOLE_CONTROL_PROTOCOL_GUID;
EFI_UGA_DRAW_PROTOCOL           *Uga = 0;
EFI_GRAPHICS_OUTPUT_PROTOCOL   *GOut = 0;
EFI_CONSOLE_CONTROL_PROTOCOL  *CCtrl = 0;
static 
EFI_PHYSICAL_ADDRESS    exp_modeinfo = 0;   ///< buffer for console & graphic modes info
static u32t             exp_mi_pages = 0;

static int                graph_mode = -1,  ///< active graph mode number
                         native_mode = -1;  ///< native graph mode, was set before we occur
static INT32         initial_console;
extern UINT32                UGAOnly;

static CHAR16 boxchars10[] = {
             0x25BA, 0x25C4, '.',    '!',    '.',    '$',    '_',    '.',
             0x2191, 0x2193, 0x25BA, 0x25C4, '.',    '.',    0x25B2, 0x25BC };

/* actually, double/single line intersection chars looks ugly in my EFI bios.
   may be this is common bug, so replace it to double & single */
static CHAR16 boxcharsB0[] = {
#if 1 // this is replacement
/* 0xB0 */   0x2591, 0x2591, 0x2591, 0x2502, 0x2524, 0x2524, 0x2563, 0x2557,
/* 0xB8 */   0x2557, 0x2563, 0x2551, 0x2557, 0x255D, 0x255D, 0x2518, 0x2510,
/* 0xC0 */   0x2514, 0x2534, 0x252C, 0x251C, 0x2500, 0x253C, 0x251C, 0x2560,
/* 0xC8 */   0x255A, 0x2554, 0x2569, 0x2566, 0x2560, 0x2550, 0x256C, 0x2569,
/* 0xD0 */   0x2569, 0x2566, 0x2566, 0x255A, 0x255A, 0x2554, 0x2554, 0x256C,
/* 0xD8 */   0x253C, 0x2518, 0x250C, 0x2588, 0x2588, ' '   , ' '   , 0x2588 };
#else // and this is how it should be
/* 0xB0 */   0x2591, 0x2591, 0x2591, 0x2502, 0x2524, 0x2561, 0x2562, 0x2556,
/* 0xB8 */   0x2555, 0x2563, 0x2551, 0x2557, 0x255D, 0x255C, 0x255B, 0x2510,
/* 0xC0 */   0x2514, 0x2534, 0x252C, 0x251C, 0x2500, 0x253C, 0x255E, 0x255F,
/* 0xC8 */   0x255A, 0x2554, 0x2569, 0x2566, 0x2560, 0x2550, 0x256C, 0x2567,
/* 0xD0 */   0x2568, 0x2564, 0x2565, 0x2559, 0x2558, 0x2552, 0x2553, 0x256B,
/* 0xD8 */   0x256A, 0x2518, 0x250C, 0x2588, 0x2588, ' '   , ' '   , 0x2588 };
#endif

void vio_init(void) {
   EFI_STATUS  Status;
   INT32           ii;
   u32t        memreq, idx;
   vio_getmode(&modex, &modey);
   
   //Print (L"Current Mode = %d (%d x %d)\n", (u32t)ST->ConOut->Mode->Mode, modex, modey);
   // mode count + 1 for missing initial mode
   memreq = (ST->ConOut->Mode->MaxMode + 2) * sizeof(struct console_mode);
   initial_console = ST->ConOut->Mode->Mode;

   // allow console output if this protocol available
   Status = BS->LocateProtocol(&ConCtrlGuid, 0, (VOID**)&CCtrl);
   if (!EFI_ERROR(Status)) vio_conlock(0); else CCtrl = 0;

   /* this is the way from EDK, but there is no such bindings in my BIOS, so use
      LocateProtocol as second chance */
   GOut = 0; Uga = 0;
   if (!UGAOnly) {
      Status = BS->HandleProtocol(ST->ConsoleOutHandle, &GraphOutGuid, (VOID**)&GOut);
      if (EFI_ERROR(Status)) GOut = 0;
   }
   if (!GOut) {
      Status = BS->HandleProtocol(ST->ConsoleOutHandle, &UgaDrawProtocol, (VOID**)&Uga);
      if (EFI_ERROR(Status)) Uga = 0;
   }
   if (!GOut && !Uga) {
      if (!UGAOnly) {
         Status = BS->LocateProtocol(&GraphOutGuid, 0, (VOID**)&GOut);
         if (EFI_ERROR(Status)) GOut = 0;
      }
      if (!GOut) {
         Status = BS->LocateProtocol(&UgaDrawProtocol, 0, (VOID**)&Uga);
         if (EFI_ERROR(Status)) Uga = 0;
      }
   }

   if (GOut) memreq += (GOut->Mode->MaxMode + 1) * sizeof(struct graphic_mode);
      else
   if (Uga) memreq += 3 * sizeof(struct graphic_mode);

   // Print (L"GOut %X, Uga %X\n", GOut, Uga);

   exp_modeinfo = PageAlloc(exp_mi_pages = Round4k(memreq)>>12);
   con_modeinfo = (struct console_mode*)exp_modeinfo;
   grf_modeinfo = (struct graphic_mode*)(con_modeinfo + ST->ConOut->Mode->MaxMode + 1);

   for (ii=0, con_modes=0; ii<=ST->ConOut->Mode->MaxMode; ii++) {
      UINTN  xx=0, yy=0;
      EFI_STATUS st = ST->ConOut->QueryMode(ST->ConOut, ii, &xx, &yy);

      // Print (L"Mode %d -> %d x %d\n", (u32t)ii, xx, yy);

      if (!EFI_ERROR(st) && xx & yy) {
         con_modeinfo[con_modes].conmode_x      = (u32t)xx;
         con_modeinfo[con_modes].conmode_y      = (u32t)yy;
         con_modeinfo[con_modes].conmode_number = ii;
         con_modes++;
         if (xx==80)
            if (yy==25) mode25 = ii; else
               if (yy==43) mode43 = ii; else
                  if (yy==50) mode50 = ii;
      }
   }
   // check that current console mode is in the list
   for (idx=0; idx<con_modes; idx++)
      if (con_modeinfo[idx].conmode_x==modex && con_modeinfo[idx].conmode_y==modey
         && con_modeinfo[idx].conmode_number==initial_console) break;
   // if no one - just add it (situation is real)
   if (idx>=con_modes) {
      con_modeinfo[con_modes].conmode_x      = modex;
      con_modeinfo[con_modes].conmode_y      = modey;
      con_modeinfo[con_modes].conmode_number = initial_console;
      con_modes++;
      if (modex==80)
         if (modey==25) mode25 = initial_console; else
            if (modey==43) mode43 = initial_console; else
               if (modey==50) mode50 = initial_console;
   }
   // force it with any resolution, if no 80x25 found
   if (mode25<0) mode25 = initial_console;

   if (GOut) {
      // Print (L"%d graphic modes\n", GOut->Mode->MaxMode);

      for (ii=0, grf_modes=0; (u32t)ii<=GOut->Mode->MaxMode; ii++) {
         EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *mi;
         UINTN                            mi_size;  
         EFI_STATUS st = GOut->QueryMode (GOut, ii, &mi_size, &mi);

         if (!EFI_ERROR(st) && mi->HorizontalResolution && mi->VerticalResolution) {
            struct graphic_mode      *emi;
            EFI_GRAPHICS_PIXEL_FORMAT fmt = mi->PixelFormat;

            /* Print (L"Mode %d -> %d x %d %d\n", (u32t)ii, mi->HorizontalResolution,
               mi->VerticalResolution, fmt); */
            if (fmt==PixelRedGreenBlueReserved8BitPerColor || fmt==PixelBitMask
               || fmt==PixelBlueGreenRedReserved8BitPerColor) 
            {
               emi = grf_modeinfo + grf_modes;
               
               emi->grfmode_x      = mi->HorizontalResolution;
               emi->grfmode_y      = mi->VerticalResolution;
               emi->grfmode_number = ii;

               if (fmt==PixelBitMask) {
                  u32t mask = 0;
                  mask += emi->grfmode_mred   = mi->PixelInformation.RedMask;
                  mask += emi->grfmode_mgreen = mi->PixelInformation.GreenMask;
                  mask += emi->grfmode_mblue  = mi->PixelInformation.BlueMask;
                  emi->grfmode_mres = mi->PixelInformation.ReservedMask;

                  if (mask==0x7FFF) emi->grfmode_bpp = 15; else
                  if (mask==0xFFFF) emi->grfmode_bpp = 16; else
                  if (mask==0xFFFFFF) emi->grfmode_bpp = emi->grfmode_mres?32:24;
                     else continue;
               } else {
                  emi->grfmode_bpp    = 32;
                  if (fmt==PixelRedGreenBlueReserved8BitPerColor) {
                     emi->grfmode_mred   = 0xFF;
                     emi->grfmode_mblue  = 0xFF0000;
                  } else {
                     emi->grfmode_mred   = 0xFF0000;
                     emi->grfmode_mblue  = 0xFF;
                  }
                  emi->grfmode_mgreen = 0xFF00;
                  emi->grfmode_mres   = 0xFF000000;
               }
               // what kind of idiot define this?
               emi->grfmode_pitch  = (Round8(emi->grfmode_bpp)>>3) * mi->PixelsPerScanLine;
               // save initial mode
               if (GOut->Mode->Mode==ii) native_mode = grf_modes;

               grf_modes++;
            }
            FreePool(mi);
         }
      }
   } else
   if (Uga) {
      struct graphic_mode    *gmi;
      UINT32           xx=0, yy=0,
                     cbits, rrate;
      EFI_STATUS st = Uga->GetMode(Uga, &xx, &yy, &cbits, &rrate);

      /* UGA guarantee 800x600x32 and no way to query mode list, but we
         can check current mode and if it not 800x600 - use it too */
      grf_modes = 0;
      if (!EFI_ERROR(st) && xx & yy)
         if (xx!=800 || yy!=600) {
            gmi = grf_modeinfo + grf_modes;
            gmi->grfmode_x      = xx;
            gmi->grfmode_y      = yy;
            gmi->grfmode_number = rrate;
            native_mode = grf_modes++;
         } else
            native_mode = grf_modes;
      gmi = grf_modeinfo + grf_modes;
      gmi->grfmode_x      = 800;
      gmi->grfmode_y      = 600;
      gmi->grfmode_number = 60;
      grf_modes++;
      for (ii=0; ii<(int)grf_modes; ii++) {
         gmi = grf_modeinfo + ii;
         // bpp is always 32, because Blit function accept only RGBA data
         gmi->grfmode_bpp    = 32;
         gmi->grfmode_mred   = 0xFF0000;
         gmi->grfmode_mgreen = 0xFF00;
         gmi->grfmode_mblue  = 0xFF;
         gmi->grfmode_mres   = 0xFF000000;
         gmi->grfmode_pitch  = gmi->grfmode_x * 4;
      }
   }
   graph_mode = -1;
}

/** lock/unlock console text output */
void vio_conlock(int lock) {
   if (CCtrl) {
      EFI_CONSOLE_CONTROL_SCREEN_MODE  cm = EfiConsoleControlScreenGraphics;

      EFI_STATUS  Status = CCtrl->GetMode(CCtrl, &cm, 0, 0);
      if (!EFI_ERROR(Status)) {
         EFI_CONSOLE_CONTROL_SCREEN_MODE nm = lock ? EfiConsoleControlScreenGraphics:
                                                     EfiConsoleControlScreenText;
         if (cm!=nm) CCtrl->SetMode(CCtrl,nm);
      }
   }
}

u32t vio_charout(u8t ch) {
   CHAR16 str[4];
   u32t    rc = 0;

   if (ch>=0x20 && ch<0x7F) str[0] = ch; else
   if (ch>=0x10 && ch<0x20) str[0] = boxchars10[ch-0x10]; else
   if (ch>=0xB0 && ch<0xE0) str[0] = boxcharsB0[ch-0xB0]; else
   switch (ch) {
      case 8: case 10: case 13: str[0] = ch; break;
      case 0xF8: str[0] = 0x00B0; break;
#if 0
      case 0xAE: str[0] = 0x00AB; break;
      case 0xAF: str[0] = 0x00BB; break;
      case 0xF1: str[0] = 0x00B1; break;
      case 0xF9: str[0] = 0x00B7; break;
      case 0xFA: str[0] = 0x2027; break;
      case 0xFE: str[0] = 0x25A0; break;
#endif
      default:
         str[0] = '.';
   }
   str[1] = 0;

   if (ch=='\n' || ch>=0x20 && ST->ConOut->Mode->CursorColumn==modex-1) rc++;
   // \n is \n\r in vio_charout()
   if (ch=='\n') { str[1] = '\r'; str[2] = 0; }
   ST->ConOut->OutputString(ST->ConOut, str);
   // update line counter
   if (rc && Header32) Header32->vio_ttylines+=rc;
   return rc;
}

u32t vio_strout(const char *str) {
   u32t rc = 0;
   while (*str) rc += vio_charout((u8t)*str++);
   return rc;
}

u8t vio_getmode(u32t *cols, u32t *lines) {
   UINTN  xx, yy;
   int    rc;

   if (graph_mode>=0) rc = 0; else {
      EFI_STATUS st = ST->ConOut->QueryMode(ST->ConOut, ST->ConOut->Mode->Mode, &xx, &yy);
      rc = !EFI_ERROR(st)?1:0;
   }
   if (cols)  *cols  = rc?(u32t)xx:0;
   if (lines) *lines = rc?(u32t)yy:0;
   return rc;
}

static void leave_graphics(void) {
   /* try to return native graphics mode first (else my PC`s BIOS going mad
      with unaligned output of partial image, hangs and so on...) */
   if (native_mode>=0 && graph_mode>=0 && graph_mode!=native_mode)
      grf_setmode(native_mode);

   vio_conlock(0);
   graph_mode = -1;
}

static EFI_STATUS conout_setmode(INT32 mode_number) {
   EFI_STATUS res;
   // disable APIC timer, mt_yield() will restore it after exit to 32-bit
   if (lapic) lapic[APIC_LVT_TMR] = APIC_DISABLE;

   res = ST->ConOut->SetMode(ST->ConOut, mode_number); 

   return res;
}

void vio_term(void) {
   // restore initial console mode if we`re in graphic now
   if (native_mode>=0 && graph_mode>=0 && graph_mode!=native_mode) {
      leave_graphics();
      conout_setmode(initial_console); 
   }

   con_modeinfo = 0;  con_modes = 0;
   grf_modeinfo = 0;  grf_modes = 0;

   if (exp_modeinfo) {
      BS->FreePages(exp_modeinfo, exp_mi_pages);
      exp_modeinfo = 0;  exp_mi_pages = 0;
   }
}

void vio_setmode(u32t lines) {
   leave_graphics();

   if (lines==25) {
      if (mode25>=0) conout_setmode(mode25); 
   } else
   if (lines==43 && mode43>=0) conout_setmode(mode43); else
   if ((lines==43 || lines==50) && mode50>=0) conout_setmode(mode50);
   // Reset() code in EDK makes the same
   ST->ConOut->ClearScreen(ST->ConOut);
   ST->ConOut->SetAttribute(ST->ConOut, 0x07);
   // update modex/modey
   vio_getmode(&modex, &modey);
}

int vio_setmodeex(u32t cols, u32t lines) {
   u32t ii;
   if (!con_modeinfo) return 0;

   for (ii=0; ii<con_modes; ii++)
      if (con_modeinfo[ii].conmode_x==cols && con_modeinfo[ii].conmode_y==lines) {
         EFI_STATUS  st;
         // return native mode (all consoles assume it on screen)
         leave_graphics();

         st = conout_setmode(con_modeinfo[ii].conmode_number);
         if (EFI_ERROR(st)) {
            st = conout_setmode(mode25); 
            if (EFI_ERROR(st)) return 0;
         }
         // update modex/modey
         vio_getmode(&modex, &modey);
         return 1;
      }
   return 0;
}

void vio_clearscr(void) {
   ST->ConOut->ClearScreen(ST->ConOut);
}

void vio_setpos(u32t line, u32t col) {
   if (line>modey-1) line = modey-1;
   if (col >modex-1) col  = modex-1;

   // update line counter
   if (Header32 && line!=ST->ConOut->Mode->CursorRow)
      Header32->vio_ttylines += line - ST->ConOut->Mode->CursorRow;

   ST->ConOut->SetCursorPosition(ST->ConOut, col, line);
}

void vio_getpos(u32t *line, u32t *col) {
   if (line) *line = ST->ConOut->Mode->CursorRow;
   if (col)  *col = ST->ConOut->Mode->CursorColumn;
}

void vio_setcolor(u16t color) {
   // just drop high bit of backgroud
   ST->ConOut->SetAttribute (ST->ConOut, color&0x7F);
}

void vio_showcursor(u32t state) {
   ST->ConOut->EnableCursor(ST->ConOut, state);
}

u32t vio_enummodes(struct console_mode **mi) {
   if (mi) *mi = con_modeinfo;
   return con_modes;
}

u32t grf_enummodes(struct graphic_mode **mi, u32t *vmemptr, u32t *vmemsize) {
   static int FirstTime = 0;
   if (!FirstTime) {
      FirstTime = 1;
      // dump protocol presence to QSINIT log on first call
      log_it(2, L"UGA:%s, GOut:%s (%x)\n", Uga?L"yes":L"no", GOut?L"yes":L"no",
         GOut?GOut->Mode->FrameBufferBase:0);
      DumpConfigTable();
   }
   if (mi) *mi = grf_modeinfo;
   if (vmemptr)  *vmemptr  = 0;
   if (vmemsize) *vmemsize = 0;

   if (GOut && GOut->Mode->FrameBufferBase<FFFF) {
      if (vmemptr)  *vmemptr  = (u32t)GOut->Mode->FrameBufferBase;
      if (vmemsize) *vmemsize = (u32t)GOut->Mode->FrameBufferSize;
   }
   return grf_modes;
}

u32t grf_setmode(u32t mode) {
   u32t       rc = 0;
   EFI_STATUS st = 0;
   if (mode>=grf_modes) return 0;
   /* this call is, in fact, VESA BIOS call with switching to real mode.
      And we have APIC timer running - a short way to ruin all.
      Disable it, mt_yield() will restore it after exit to 32-bit */
   if (lapic) lapic[APIC_LVT_TMR] = APIC_DISABLE;

   if (GOut) {
      st = GOut->SetMode(GOut, grf_modeinfo[mode].grfmode_number);
      if (!EFI_ERROR(st)) rc = 1;
   } else
   if (Uga) {
      st = Uga->SetMode(Uga, grf_modeinfo[mode].grfmode_x,
         grf_modeinfo[mode].grfmode_y, grf_modeinfo[mode].grfmode_bpp,
            grf_modeinfo[mode].grfmode_number);
      if (!EFI_ERROR(st)) rc = 2;
   }
   if (EFI_ERROR(st)) log_it(2, L"Set mode error %x\n", st);
   // disable console
   if (rc) {
      vio_conlock(1);
      graph_mode = mode;
   }
   return rc;
}


u32t grf_blit(u32t x, u32t y, u32t dx, u32t dy, void *buf, u32t pitch) {
   EFI_STATUS st;
   u32t       rc = 0;

   if (graph_mode<0) return 0;

   if (GOut) {
      st = GOut->Blt(GOut, buf, EfiBltBufferToVideo, 0, 0, x, y, dx, dy, pitch);
      if (!EFI_ERROR(st)) rc = 1;
   } else
   if (Uga) {
      st = Uga->Blt(Uga, buf, EfiUgaBltBufferToVideo, 0, 0, x, y, dx, dy, pitch);
      if (!EFI_ERROR(st)) rc = 1;
   }
   return rc;
}

#define Convert15to16(ww)  ((ww)<<1&0xFFC0|(((ww)&0x03E0)!=0?0x0020:0)|(ww)&0x001F)
#define Convert16toRGB(ww) ((((ww)&0xF800)<<8)|(((ww)&0x07E0)<<5)|(((ww)&0x001F)<<3))
#define Convert16toBGR(ww) ((((ww)&0xF800)>>8)|(((ww)&0x07E0)<<5)|(((ww)&0x001F)<<19))

u32t grf_clear(u32t x, u32t y, u32t dx, u32t dy, u32t color) {
   struct graphic_mode *cm;
   EFI_STATUS           st;
   u32t           px32, rc = 0;
                     
   if (graph_mode<0) return 0;
   cm = grf_modeinfo + graph_mode;

   // we can`t get 1-4-8 bit here, so this will be only 15/16
   if (cm->grfmode_bpp<24) {
      // this is NOT 15/16 bits
      if (cm->grfmode_mgreen!=0x3E0 && cm->grfmode_mgreen!=0x7E0) return 0;
      // made it 16
      if (cm->grfmode_mgreen==0x3E0) color = Convert15to16(color);
      // and then 32
      px32 = cm->grfmode_mblue==0x1F ? Convert16toRGB(color) : Convert16toBGR(color);
   } else
      px32 = color;

   if (GOut) {
      EFI_GRAPHICS_OUTPUT_BLT_PIXEL_UNION px;
      px.Raw = px32;
      st = GOut->Blt(GOut, &px.Pixel, EfiBltVideoFill, 0, 0, x, y, dx, dy, 0);
      if (!EFI_ERROR(st)) rc = 1;
   } else
   if (Uga) {
      EFI_UGA_PIXEL_UNION px;
      px.Raw = px32;
      st = Uga->Blt(Uga, &px.Pixel, EfiUgaVideoFill, 0, 0, x, y, dx, dy, 0);
      if (!EFI_ERROR(st)) rc = 1;
   }
   return rc;
}
