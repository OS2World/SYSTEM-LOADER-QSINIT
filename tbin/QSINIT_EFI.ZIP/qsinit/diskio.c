//
// QSINIT EFI loader
// disk & boot partition i/o
//
#include "qsloader.h"
#include "efilib.h"
#include "dskinfo.h"
#include "qsinit.h"

#define BIOS_MAX_CYLINDERS         1024
#define BIOS_MAX_NUMHEADS           255
#define BIOS_MAX_SECTORSPERTRACK     63

extern u8t             *mfsd_openname;
extern EFI_LOADED_IMAGE  *LoadedImage;
extern EFI_DEVICE_PATH    *DevicePath;

static EFI_BLOCK_IO        **BlockDev = 0;
static u32t             BlockDevCount;

u32t dsk_init(exp32_table *etab, struct qs_diskinfo *qdd) {
   EFI_STATUS         st;
   UINTN          hcount;
   EFI_HANDLE   *handles;
   u32t               ii;
   // empty by default
   etab->qd_fdds      = 0;
   etab->qd_hdds      = 0;

   st = LibLocateHandle(ByProtocol, &BlockIoProtocol, 0, &hcount, &handles);
   if (EFI_ERROR(st) || !hcount) return 0;

   BlockDev = (EFI_BLOCK_IO**)AllocateZeroPool(sizeof(EFI_BLOCK_IO*) * hcount);
   if (!BlockDev) return 0;

   BlockDevCount = 0;

   // enum BLOCK_IO devices
   for(ii=0; ii<hcount; ii++) {
      EFI_BLOCK_IO        *BlkIo;
      EFI_BLOCK_IO_MEDIA  *Media;
      struct qs_diskinfo     *di = qdd + MAX_QS_FLOPPY + BlockDevCount;
      // Get the BLOCK_IO Protocol Interface to the device
      st = BS->HandleProtocol(handles[ii], &BlockIoProtocol, (VOID*)&BlkIo);
      // Handle does not support the BLOCK_IO protocol
      if (EFI_ERROR(st) || BlkIo==0) continue;

      Media = BlkIo->Media;

      if (!Media->LogicalPartition && Media->MediaPresent && Media->BlockSize>=512 &&
         Media->BlockSize<=4096)
      {
         RtZeroMem(di, sizeof(struct qs_diskinfo));
         di->qd_sectors     = Media->LastBlock+1;

         di->qd_sectorsize  = Media->BlockSize;
         // bit shift must be possible (i.e. only 512, 1024, 2048 & 4096 sector size)
         di->qd_sectorshift = bsf64(Media->BlockSize);
         if (1<<di->qd_sectorshift != Media->BlockSize) continue;

         di->qd_biosdisk    = 0x80 + (u8t)BlockDevCount;
         di->qd_mediatype   = Media->ReadOnly ? 2 : 3;
         di->qd_flags       = HDDF_LBAON|HDDF_PRESENT|HDDF_LBAPRESENT;
         // CHS dances
         di->qd_cyls        = 1024;
         di->qd_heads       = 31;
         di->qd_spt         = 17;
         while (di->qd_cyls*di->qd_spt*di->qd_heads < di->qd_sectors) {
            if (di->qd_spt<63) {
               di->qd_spt   = (di->qd_spt   + 1 & 0xF0) * 2 - 1; continue; 
            }
            if (di->qd_heads<255) {
               di->qd_heads = (di->qd_heads + 1 & 0xF0) * 2 - 1; continue; 
            }
            break;
         }
         di->qd_cyls        = (u32t)(di->qd_sectors / (di->qd_spt*di->qd_heads));
         di->qd_chsheads    = di->qd_heads;
         di->qd_chsspt      = di->qd_spt;

         BlockDev[BlockDevCount] = BlkIo;
         // disk limit reached
         if (++BlockDevCount == MAX_QS_DISK-MAX_QS_FLOPPY) break;
      }
   }
   // Free the resources allocated from pool.
   FreePool(handles);

   etab->qd_hdds = BlockDevCount;

   return BlockDevCount;
}

// result is reversed in comparition with common practice, i.e. 0 - success, 1 - error
u32t dsk_io(struct qs_diskinfo *di, u64t start, u32t sectors, u32t writeflag) {
   u32t  idx;
   // check for all requirements
   if (!di || !sectors || !BlockDev || !Header32) return 1;

   idx = di->qd_biosdisk & 0x7F;
   //log_it(2, L"dsk_io(%d,%ld,%d,%d)\n", idx, start, sectors, writeflag);
   //if (writeflag) return 1;

   while (idx<BlockDevCount) {
      EFI_BLOCK_IO_MEDIA  *Media = BlockDev[idx]->Media;
      UINT32             MediaId = Media->MediaId;
      UINTN               iosize = sectors<<di->qd_sectorshift;
      EFI_STATUS   st;
      u32t         rc;

      if (iosize>DISKBUF_SIZE) break;

      st = (writeflag ? BlockDev[idx]->WriteBlocks : BlockDev[idx]->ReadBlocks)
         (BlockDev[idx], MediaId, start, iosize, (void*)(u64t)Header32->DiskBufPM);
      rc = EFI_ERROR(st)?1:0;
      // call Flush() on removable
      if (rc && writeflag && Media->RemovableMedia)
         BlockDev[idx]->FlushBlocks(BlockDev[idx]);

      return rc;
   }
   return 1;
}

void dsk_term(void) {
   if (BlockDev) { FreePool(BlockDev); BlockDev = 0; }
}

static EFI_FILE_IO_INTERFACE    *Vol = 0;
static EFI_FILE_HANDLE        CurDir = 0;
static EFI_FILE_HANDLE        RootFs = 0;
static EFI_FILE_HANDLE    FileHandle = 0;
static CHAR16               *DevPath = 0;

u16t mfs_open (u32t plen) {
   static CHAR16    FName[130 + MFSD_NAME_LEN];
   EFI_STATUS      Status;
   UINTN           ii, jj;
   u32t        *PFileSize = (u32t*)(u64t)plen;

   *PFileSize = FFFF;

   // first time use - init boot partition volume
   if (!Vol) {
      // Open the volume for the device where the EFI OS Loader was loaded from.
      Status = BS->HandleProtocol (LoadedImage->DeviceHandle, &FileSystemProtocol, (VOID*)&Vol);
      if (EFI_ERROR(Status)) { Vol = 0; return 1; }

      Status = Vol->OpenVolume (Vol, &RootFs);
      if (EFI_ERROR(Status)) { Vol = 0; return 2; }

      CurDir  = RootFs;
      DevPath = DevicePathToStr(LoadedImage->FilePath);
      if (!DevPath || StrLen(DevPath)>128) { Vol = 0; return 3; }

      ;

      for (ii = StrLen(DevPath); ii>0 && DevPath[ii]!='/' && DevPath[ii]!='\\'; ii--);
      DevPath[ii] = 0;
      if (DevPath[ii-1] == '\\' || DevPath[ii-1] == '/') DevPath[ii-1] = 0;
   }
   // if file asking with lead '/' - assume direct path, else \EFI\BOOT dir
   if (mfsd_openname[0]!='/' && mfsd_openname[0]!='\\') {
      StrCpy(FName,DevPath);
      ii = StrLen(FName);
      FName[ii++] = '\\';
   } else
      ii = 0;
   jj = 0;
   // char -> char16
   while ((FName[ii++] = mfsd_openname[jj++]));

   Status = CurDir->Open (CurDir, &FileHandle, FName, EFI_FILE_MODE_READ, 0);
   if (EFI_ERROR(Status)) {
      //Print(L"Can not open the file %s\n",FName);
      log_it(3, L"Can not open the file %s\n", FName);
      //key_read();
      return 4;
   } else {
      EFI_FILE_INFO *fi = LibFileInfo(FileHandle);
      u16t           rc = 0;

      if (!fi) rc = 5; else {
         if (fi->FileSize>=_512MB) rc = 6; else
            *PFileSize = (u32t)fi->FileSize;
         FreePool(fi);
      }
      // Print(L"File %s, rc %d, size %d\n", FName, (u32t)rc, *PFileSize);
      if (rc) {
         FileHandle->Close(FileHandle);
         FileHandle = 0;
      }
      return rc;
   }
}

u32t mfs_read (u32t offset, u32t buf, u32t readsize) {
   if (FileHandle) {
      u8t    *bufptr = (u8t*)(u64t)buf;
      UINTN   rdsize = readsize;
      EFI_STATUS  st = FileHandle->SetPosition(FileHandle, offset);
      if (EFI_ERROR(st)) return 0;

      st = FileHandle->Read(FileHandle, &rdsize, bufptr);
      if (EFI_ERROR(st)) return 0;

      return (u32t)rdsize;
   }
   return 0;
}

u32t mfs_close(void) {
   if (FileHandle) {
      FileHandle->Close(FileHandle);
      FileHandle = 0;
   }
   return 0;
}

u32t mfs_term(void) {
   mfs_close();
   if (DevPath) { FreePool(DevPath); DevPath = 0; }
   Vol = 0;
   return 0;
}
