//
// QSINIT EFI loader
// time functions
//
#include "qsloader.h"
#include "efilib.h"

// return number of TSC in 10000 dec ops
u64t IODelayLoop(void);

u64t CountsIn55ms = 0;

#define CALC_INTERVAL  (4)

/// return IODelay value
u16t tm_calibrate(void) {
   EFI_EVENT   ev;
   EFI_STATUS  st = BS->CreateEvent(EVT_TIMER, 0, NULL, NULL, &ev);
   u64t  newdelay = 1000;

   if (!EFI_ERROR(st)) {
      /* calc number of CPU Tics in four 55 ms intervals */
      st = BS->SetTimer(ev, TimerRelative, 549320*CALC_INTERVAL);
      if (!EFI_ERROR(st)) {
         u64t  start = ReadTSC(), ticks500ns, iolen, end;
         UINTN   idx;

         iolen = IODelayLoop();
         BS->WaitForEvent (1, &ev, &idx);
         end   = ReadTSC();
         //Print(L"start: %X end: %X...\n", start, end);
         // ticks in 55ms
         CountsIn55ms = (end - start) / CALC_INTERVAL;
         // ticks in 500ns
         ticks500ns   = (end - start) / (54932*CALC_INTERVAL*2);
         // IODelay value (loops in 500 ns)
         newdelay     = ticks500ns * 20000 / iolen;
         // just set fixed value if calculation failed
         if (!newdelay || newdelay>15000) newdelay = 1000;
      }
      BS->CloseEvent(ev);
   }

   if (!CountsIn55ms) CountsIn55ms = 1000000;
   if (Header32) Header32->countsIn55ms = CountsIn55ms;
   return (u16t)newdelay;
}
 
/** return timer counter value (18.2 times per sec, for randomize, etc).
    not used now, calculated in 32-bit part. */
u32t tm_counter(void) {
   if (!CountsIn55ms) {
      tm_calibrate();
      log_it(2, L"%X ticks in 55 ms...\n", CountsIn55ms);
   }
   return (u32t)(ReadTSC()/CountsIn55ms);
}

/// return time/date in dos format, but 33-bits - low bit for truncated second
u64t tm_getdate(void) {
   EFI_TIME  now;

   if (RT->GetTime(&now,0)) return 0x40210000<<1; // 1-1-2012

   return now.Second + ((u64t)((now.Minute<<5) + (now.Hour<<11) + 
      (now.Day<<16) + (now.Month<<21) + ((now.Year-1980)<<25))<<1);
}

/// set current time (with 2 seconds granularity)
void tm_setdate(u32t dostime) {
   EFI_TIME    nt;
   EFI_STATUS  st;

   RtZeroMem(&nt, sizeof(EFI_TIME));
   // call to fill some strange fields like TimeZone & Daylight
   RT->GetTime(&nt,0);

   nt.Year    = (dostime>>25) + 1980;
   nt.Month   = dostime>>21 & 0xF;
   nt.Day     = dostime>>16 & 0x1F;
   nt.Hour    = dostime>>11 & 0x1F;
   nt.Minute  = dostime>>5 & 0x3F;
   nt.Second  = (dostime & 0x1F) << 1;

   st = RT->SetTime(&nt);
   if (EFI_ERROR(st)) log_it(3, L"SetTime error %X\n", st);
}
