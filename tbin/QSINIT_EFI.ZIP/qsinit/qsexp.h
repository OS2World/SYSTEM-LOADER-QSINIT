//
// QSINIT
// 32-bit part export table
//
#ifndef QS_EFI_EXP32
#define QS_EFI_EXP32

#include "qsloader.h"

#pragma pack(1)

typedef struct {
   u32t           size;   ///< struct size
   u32t          entry;   ///< 32-bit entry point (fixups applied to this to!)
   u32t      phmembase;
   u32t       highbase;
   u32t        highlen;
   u32t       logrmbuf;   ///< 4k buffer for log until real log will be started
   u32t       qd_array;   ///< array of disk data to fill
   u32t      DiskBufPM;   ///< 32k buffer for i/o ops
   u32t        gdt_pos;   ///< current GDT                    
   u32t    pbin_header;   ///< pointer to BIN_HEADER of 32-bit part
   u32t          ofs64;   ///< offset of call point
   u32t          sel64;   ///< x64 selector
   u32t          ret64;   ///< far 16:32 address to return
   u32t       flat32cs;   ///< 32-bit cs selector
   u32t  mfsd_openname;   ///< hlp_fopen() file name ptr
   u32t          ret32;   ///< offset to return from 32-bit code
   u32t   vio_ttylines;   ///< global console new line counter
   u32t         xcpt64;   ///< offset of 32-bit part of common exception handler
   u32t         xcpt32;   ///< offset to return from 32-bit exception code

   u16t       logrmpos;   ///< pos in logrmbuf (yes, we can write something!)
   u8t         qd_fdds;   ///< number of floppies (always 0)
   u8t         qd_hdds;   ///< number of hdds
   u16t       gdt_size;   ///< GDT size in bytes
   u16t     gdt_lowest;   ///< lowest usable selector
   u16t        IODelay;   ///< # of dec ops to make 500 ns timeout
   u8t        safeMode;   ///< safe mode flag
   u8t        reserved;
   u64t        bootlen;   ///< boot partition length, in sectors
   u64t      bootstart;   ///< boot partition start, in sectors
   u32t       bootdisk;   ///< boot disk index or 0xFFFFFFFF
   u64t   countsIn55ms;   ///< # of rdtsc ticks in 55 ms (on current freq)
   u32t      acpitable;   ///< ACPI table address
   u32t     int12msize;   ///< ram size in 1st Mb (640k)
} exp32_table;

#pragma pack()
#endif // QS_EFI_EXP32
